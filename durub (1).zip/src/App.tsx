import React, { useState, useEffect, useMemo } from "react";
import { 
  Product, Order, Customer, Coupon, CMSContent, OrderItem,
  INITIAL_PRODUCTS, INITIAL_CMS, INITIAL_COUPONS, INITIAL_CUSTOMERS, INITIAL_ORDERS 
} from "./types";

// Layout components
import { Navbar } from "./components/Navbar";
import { Footer } from "./components/Footer";
import { BottomNav } from "./components/BottomNav";
import { Marquee } from "./components/Marquee";

// Interactive Views
import { ShopView } from "./components/ShopView";
import { ProductDetailView } from "./components/ProductDetailView";
import { CartView } from "./components/CartView";
import { AccountView } from "./components/AccountView";
import { InfoPages } from "./components/InfoPages";
import { CMSDashboard } from "./components/CMSDashboard";

// Icons
import { ArrowRight, ChevronRight, MessageSquare, Compass, Send } from "lucide-react";

export default function App() {
  // --- Persistent States from LocalStorage ---
  const [products, setProductsState] = useState<Product[]>(() => {
    const saved = localStorage.getItem("durub_products");
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [orders, setOrdersState] = useState<Order[]>(() => {
    const saved = localStorage.getItem("durub_orders");
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [customers, setCustomersState] = useState<Customer[]>(() => {
    const saved = localStorage.getItem("durub_customers");
    return saved ? JSON.parse(saved) : INITIAL_CUSTOMERS;
  });

  const [coupons, setCouponsState] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem("durub_coupons");
    return saved ? JSON.parse(saved) : INITIAL_COUPONS;
  });

  const [cmsContent, setCmsContentState] = useState<CMSContent>(() => {
    const saved = localStorage.getItem("durub_cms");
    return saved ? JSON.parse(saved) : INITIAL_CMS;
  });

  // Trackers wrapped
  const setProducts = (p: Product[] | ((prev: Product[]) => Product[])) => {
    setProductsState((prev) => {
      const next = typeof p === "function" ? p(prev) : p;
      localStorage.setItem("durub_products", JSON.stringify(next));
      return next;
    });
  };

  const setOrders = (o: Order[] | ((prev: Order[]) => Order[])) => {
    setOrdersState((prev) => {
      const next = typeof o === "function" ? o(prev) : o;
      localStorage.setItem("durub_orders", JSON.stringify(next));
      return next;
    });
  };

  const setCustomers = (c: Customer[] | ((prev: Customer[]) => Customer[])) => {
    setCustomersState((prev) => {
      const next = typeof c === "function" ? c(prev) : c;
      localStorage.setItem("durub_customers", JSON.stringify(next));
      return next;
    });
  };

  const setCoupons = (co: Coupon[] | ((prev: Coupon[]) => Coupon[])) => {
    setCouponsState((prev) => {
      const next = typeof co === "function" ? co(prev) : co;
      localStorage.setItem("durub_coupons", JSON.stringify(next));
      return next;
    });
  };

  const setCmsContent = (cms: CMSContent | ((prev: CMSContent) => CMSContent)) => {
    setCmsContentState((prev) => {
      const next = typeof cms === "function" ? cms(prev) : cms;
      localStorage.setItem("durub_cms", JSON.stringify(next));
      return next;
    });
  };

  // --- Session states ---
  const [cartItems, setCartItems] = useState<OrderItem[]>([]);
  const [currentView, setCurrentView] = useState<string>("home"); // "home", "shop", "detail", "cart", "account", "admin", etc.
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterSubbed, setNewsletterSubbed] = useState(false);

  // --- Theme & Language States (Forced to English & Light Mode) ---
  const lang = "en";
  const theme = "light";

  useEffect(() => {
    document.documentElement.classList.remove("dark");
    document.documentElement.dir = "ltr";
    document.documentElement.lang = "en";
  }, []);

  // Email notifications log stored in state
  const [sentEmailsLog, setSentEmailsLog] = useState<{ id: string; to: string; subject: string; date: string; content: string }[]>([
    {
      id: "email-1",
      to: "john@stone.com",
      subject: "DURUB Receipt - Thank you for your purchase (order-1011)",
      date: "2026-06-22 14:31:02",
      content: `DURUB CLIENT CONCIERGE CHRONICLE\n\nYour order order-1011 has been successfully registered. Standard Global express tracking reference is DRB893019842US.\n\nThank you for choosing DURUB.`
    }
  ]);

  const addEmailLog = (to: string, subject: string, content: string) => {
    const newLog = {
      id: `email-${Date.now()}`,
      to,
      subject,
      date: new Date().toLocaleString(),
      content
    };
    setSentEmailsLog(prev => [newLog, ...prev]);
  };

  // --- Derived states ---
  const categoriesList = useMemo(() => {
    const list = new Set(products.map(p => p.category));
    return Array.from(list);
  }, [products]);

  const featuredCampaigns = useMemo(() => {
    return products.filter(p => p.featured).slice(0, 4);
  }, [products]);

  const newArrivals = useMemo(() => {
    return products.filter(p => p.isNew).slice(0, 4);
  }, [products]);

  const bestSellers = useMemo(() => {
    return products.filter(p => p.isBestSeller).slice(0, 4);
  }, [products]);

  const totalCartCount = useMemo(() => {
    return cartItems.reduce((acc, curr) => acc + curr.quantity, 0);
  }, [cartItems]);

  // --- Handlers ---
  const handleNavigate = (view: string, category?: string) => {
    setCurrentView(view);
    setSearchQuery(""); // Clear search queries on tab shift
    if (category !== undefined) {
      setCategoryFilter(category);
    } else {
      setCategoryFilter(null);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectProduct = (p: Product) => {
    setSelectedProduct(p);
    setCurrentView("detail");
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddToBag = (product: Product, quantity: number, size: string, color: string) => {
    // Check if garment instance exists in the current bag
    const idx = cartItems.findIndex(
      i => i.product.id === product.id && i.selectedSize === size && i.selectedColor === color
    );

    if (idx > -1) {
      const copy = [...cartItems];
      copy[idx].quantity += quantity;
      setCartItems(copy);
    } else {
      setCartItems([...cartItems, { product, quantity, selectedSize: size, selectedColor: color }]);
    }

    // Automatically send details log to rah.ism.bakr@gmail.com (admin / visitor ledger)
    addEmailLog(
      "rah.ism.bakr@gmail.com",
      `[ATELIER BASKET SELECTION] Added: ${product.name} (Size: ${size} / Color: ${color})`,
      `Greetings Atelier Master,\n\nA visitor has successfully selected a garment silhouette and placed it in their bag.\n\nSELECTION SPECS:\n- Silhouette: ${product.name}\n- Category: ${product.category}\n- Price: EGP ${product.price.toFixed(2)}\n- Selected Size: ${size || "Not Selected"}\n- Selected Color: ${color || "Default"}\n- Quantity: ${quantity}\n- Item Reference ID: ${product.id}\n- Preview Image: ${product.images[0]}\n\nThis coordinate has been safely committed to the active transaction registry.`
    );
  };

  const handleCancelOrderFromAccount = (orderId: string) => {
    setOrders(orders.map(o => {
      if (o.id === orderId) {
        addEmailLog(
          o.customerEmail,
          `DURUB Transaction Reversed - ${o.id}`,
          `Greeting ${o.customerName},\n\nYour order ${o.id} charge has been fully reversed and refunded to your original payment card.\n\nThank you for choosing DURUB.`
        );
        return { ...o, status: "Cancelled" };
      }
      return o;
    }));
  };

  const handleSaveNewOrderFromCheckout = (newOrder: Order) => {
    setOrders([newOrder, ...orders]);
    
    // Check if customer profile exists in storage or populate
    const match = customers.find(c => c.email.toLowerCase() === newOrder.customerEmail.toLowerCase());
    if (match) {
      setCustomers(customers.map(c => 
        c.email.toLowerCase() === newOrder.customerEmail.toLowerCase()
          ? { ...c, orders: [...c.orders, newOrder.id] }
          : c
      ));
    } else {
      const nameParts = newOrder.customerName.split(" ");
      const newCust: Customer = {
        id: `cust-${Date.now()}`,
        name: newOrder.customerName,
        email: newOrder.customerEmail,
        phone: newOrder.customerPhone,
        address: `${newOrder.shippingAddress}, ${newOrder.city}`,
        orders: [newOrder.id],
        createdAt: new Date().toISOString()
      };
      setCustomers([newCust, ...customers]);
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newsletterEmail.trim().includes("@")) {
      setNewsletterSubbed(true);
      setNewsletterEmail("");
      setTimeout(() => setNewsletterSubbed(false), 6000);
    }
  };

  // Testimonials database
  const testimonies = [
    {
      author: "LEONARD S.",
      location: "LONDON",
      text: "THE DRAPE OF THE SEERSUCKER SHIRT COMPLEMENTS AIR MOVEMENT PERFECTLY. A RARITY IN PREMIUM STORES TODAY."
    },
    {
      author: "MARCUS O.",
      location: "MILANO",
      text: "Meticulous master tailoring parameters! DURUB is my permanent source for structural essentials."
    },
    {
      author: "KENJI T.",
      location: "TOKYO",
      text: "UNCOMPROMISING TEXTURE SENSORY QUALITY. THE SUEDE JACKET DRAWS CONSTANT INQUIRIES ACROSS METROPOLITANS."
    }
  ];

  const [activeTestimony, setActiveTestimony] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveTestimony(prev => (prev + 1) % testimonies.length);
    }, 6000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-white text-stone-900 font-sans antialiased selection:bg-stone-950 selection:text-white pb-14 lg:pb-0" id="durub-root">
      
      {/* 1. Micro Promo Ribbon banner */}
      <div className="bg-zinc-950 text-white py-2 px-4 text-center text-[10px] md:text-xs font-mono tracking-widest uppercase truncate font-medium relative z-50">
        {cmsContent.promoMessage}
      </div>

      {/* 2. Micro continuous slogan marquee helper */}
      <Marquee text="DURUB ATELIER AW26 — AN ARCHITECTURAL SILENT STATEMENT — ETHICAL LIMITED CROPS" speed={30} />

      {/* 3. Navigation Header */}
      <Navbar 
        cartCount={totalCartCount}
        onNavigate={handleNavigate}
        onSearch={(q) => { setSearchQuery(q); setCurrentView("shop"); }}
        currentView={currentView}
        categories={categoriesList}
        activeCategory={categoryFilter}
      />

      {/* 4. Active Body Screens Routing */}
      <main className="flex-grow">
        
        {/* HOMEPAGE VIEW */}
        {currentView === "home" && (
          <div className="space-y-20 pb-20 animate-fade-in" id="homepage-root">
            
            {/* FULL-WIDTH HERO SECTION */}
            <section className="relative w-full aspect-[4/5] md:aspect-[16/7] bg-stone-100 overflow-hidden" id="hero-campaign">
              {/* Main Campaign Photo */}
              <img 
                src={cmsContent.hero.image} 
                alt="Campaign Canvas" 
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-[4000ms] ease-out-quint hover:scale-103"
                referrerPolicy="no-referrer"
              />
              {/* Twilight luxury shading overlay */}
              <div className="absolute inset-0 bg-stone-900/40"></div>

              {/* Large Artistic Visual Placeholder */}
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none opacity-20 z-10">
                <span className="text-[180px] sm:text-[280px] md:text-[380px] font-serif italic text-white/45 tracking-tight">D</span>
              </div>
              
              {/* Content overlay */}
              <div className="absolute inset-0 flex flex-col justify-end p-6 sm:p-12 md:p-16 text-white max-w-4xl z-20">
                <span className="text-[10px] md:text-xs font-mono tracking-[0.3em] text-stone-200 uppercase">
                  NEW SEASON HARMONY Arrivals
                </span>
                <h1 className="font-serif text-5xl sm:text-6xl md:text-7xl font-light tracking-tight text-white uppercase mt-3 leading-[0.95]">
                  {cmsContent.hero.title.includes(" / ") ? (
                    <>
                      {cmsContent.hero.title.split(" / ")[0]}
                      <br />
                      <span className="italic font-light text-stone-105">{cmsContent.hero.title.split(" / ")[1]}</span>
                    </>
                  ) : (
                    <>
                      REDEFINED
                      <br />
                      <span className="italic font-light text-stone-105">ESSENTIALS</span>
                    </>
                  )}
                </h1>
                <p className="text-stone-300 text-xs sm:text-sm uppercase tracking-widest mt-4 leading-relaxed max-w-2xl font-light">
                  {cmsContent.hero.subtitle}
                </p>

                <div className="mt-8 flex flex-wrap gap-4">
                  <button
                    onClick={() => handleNavigate("shop")}
                    className="bg-white text-stone-950 font-bold hover:bg-stone-100 text-[10px] md:text-xs font-mono tracking-widest uppercase px-8 py-4 transition-colors duration-300 select-none cursor-pointer inline-flex items-center gap-2"
                  >
                    <span>{cmsContent.hero.ctaText}</span>
                    <ArrowRight size={14} />
                  </button>
                  <button
                    onClick={() => handleNavigate("about")}
                    className="border border-white hover:bg-white/10 text-white text-[10px] md:text-xs font-mono tracking-widest uppercase px-8 py-4 transition-all duration-300 select-none cursor-pointer"
                  >
                    Atelier Journal
                  </button>
                </div>
              </div>
            </section>

            {/* CURATED THREE CATEGORIES BENTO GRID */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="featured-collections-grid">
              <div className="text-center mb-12">
                <span className="text-[10px] font-mono tracking-[0.25em] text-stone-400 uppercase">
                  Structural Curations
                </span>
                <h2 className="font-display text-xl md:text-2xl tracking-[0.2em] uppercase text-stone-950 mt-1">
                  FEATURED CAMPAIGNS
                </h2>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Panel 1 */}
                <div 
                  onClick={() => handleNavigate("shop", "Shirts")}
                  className="group relative aspect-[3/4] bg-stone-100 overflow-hidden cursor-pointer"
                >
                  <img 
                    src={cmsContent.collectionBanners.minimalistLineImage} 
                    alt="Minimalist Shirts" 
                    className="w-full h-full object-cover transition-transform duration-[1500ms] group-hover:scale-104 grayscale hover:grayscale-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-stone-900/35 group-hover:bg-stone-900/20 transition-colors"></div>
                  <div className="absolute bottom-6 left-6 text-white space-y-1">
                    <span className="text-[9px] font-mono tracking-wide text-stone-300">CURATED STUDY 01</span>
                    <p className="font-semibold text-sm tracking-widest uppercase flex items-center gap-1.5 font-display">
                      {cmsContent.collectionBanners.minimalistLineTitle} <ChevronRight size={14} />
                    </p>
                  </div>
                </div>

                {/* Panel 2 */}
                <div 
                  onClick={() => handleNavigate("shop", "Trousers")}
                  className="group relative aspect-[3/4] bg-stone-105 overflow-hidden cursor-pointer"
                >
                  <img 
                    src={cmsContent.collectionBanners.tailoredSuitingImage} 
                    alt="Tailored Trousers" 
                    className="w-full h-full object-cover transition-transform duration-[1500ms] group-hover:scale-104 grayscale hover:grayscale-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-stone-900/35 group-hover:bg-stone-900/20 transition-colors"></div>
                  <div className="absolute bottom-6 left-6 text-white space-y-1">
                    <span className="text-[9px] font-mono tracking-wide text-stone-300">CURATED STUDY 02</span>
                    <p className="font-semibold text-sm tracking-widest uppercase flex items-center gap-1.5 font-display">
                      {cmsContent.collectionBanners.tailoredSuitingTitle} <ChevronRight size={14} />
                    </p>
                  </div>
                </div>

                {/* Panel 3 */}
                <div 
                  onClick={() => handleNavigate("shop", "T-Shirts")}
                  className="group relative aspect-[3/4] bg-stone-110 overflow-hidden cursor-pointer"
                >
                  <img 
                    src={cmsContent.collectionBanners.essentialsImage} 
                    alt="Organic Knits" 
                    className="w-full h-full object-cover transition-transform duration-[1500ms] group-hover:scale-104 grayscale hover:grayscale-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-stone-900/35 group-hover:bg-stone-900/20 transition-colors"></div>
                  <div className="absolute bottom-6 left-6 text-white space-y-1">
                    <span className="text-[9px] font-mono tracking-wide text-stone-300">CURATED STUDY 03</span>
                    <p className="font-semibold text-sm tracking-widest uppercase flex items-center gap-1.5 font-display">
                      {cmsContent.collectionBanners.essentialsTitle} <ChevronRight size={14} />
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* NEW ARRIVALS GRID */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="new-arrivals-campaign">
              <div className="flex justify-between items-end mb-10 border-b border-stone-200 pb-4">
                <div>
                  <span className="text-[10px] font-mono tracking-[0.25em] text-stone-400">
                    Tactility studies
                  </span>
                  <h3 className="font-display text-xl tracking-[0.16em] uppercase text-stone-950 mt-1">
                    NEW SILHOUETTE FLIGHTS
                  </h3>
                </div>
                <button 
                  onClick={() => handleNavigate("shop")}
                  className="text-xs font-mono tracking-widest text-stone-900 hover:text-stone-500 underline uppercase cursor-pointer"
                >
                  Shop Arrivals
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {newArrivals.map((p) => (
                  <div 
                    key={p.id}
                    onClick={() => handleSelectProduct(p)}
                    className="group cursor-pointer text-left flex flex-col h-full bg-white relative"
                  >
                    <div className="aspect-[3/4] bg-stone-100 overflow-hidden relative">
                      <img src={p.images[0]} alt="Arrival" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-103" referrerPolicy="no-referrer" />
                      <span className="absolute top-2 left-2 z-10 bg-black text-white text-[8px] font-mono tracking-widest uppercase px-2 py-0.5">NEW</span>
                    </div>
                    <div className="pt-3">
                      <h4 className="text-xs uppercase tracking-wider text-stone-900 group-hover:text-stone-500 transition-colors duration-200 line-clamp-1">{p.name}</h4>
                      <p className="text-[10px] font-mono text-stone-500 mt-1">EGP {p.price.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* LUXURY SLIDES TESTIMONIAL CAROUSEL PANEL */}
            <section className="bg-stone-950 text-white py-20 px-4 md:px-8 border-y border-stone-800 text-center" id="parallax-testimonies">
              <div className="max-w-3xl mx-auto space-y-6">
                <MessageSquare size={32} className="mx-auto text-amber-500 animate-bounce" />
                
                {/* Active index testimony slide */}
                <div className="min-h-[100px] flex items-center justify-center">
                  <p className="font-display text-base md:text-xl font-light tracking-[0.15em] leading-relaxed uppercase text-stone-100 transition-all duration-500">
                    "{testimonies[activeTestimony].text}"
                  </p>
                </div>

                <div className="space-y-1">
                  <h5 className="font-mono text-xs tracking-widest text-white uppercase font-bold">
                    {testimonies[activeTestimony].author}
                  </h5>
                  <p className="text-[9px] font-mono text-stone-500 tracking-wider">
                    {testimonies[activeTestimony].location} — VERIFIED SECURE BUYER
                  </p>
                </div>

                {/* Slides indicator circles */}
                <div className="flex justify-center gap-2 pt-2">
                  {testimonies.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveTestimony(i)}
                      className={`h-1.5 w-1.5 rounded-full transition-all cursor-pointer ${
                        activeTestimony === i ? "bg-amber-500 w-4" : "bg-stone-700"
                      }`}
                    ></button>
                  ))}
                </div>
              </div>
            </section>

            {/* BEST SELLERS GRID */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="best-sellers-campaign">
              <div className="flex justify-between items-end mb-10 border-b border-stone-200 pb-4">
                <div>
                  <span className="text-[10px] font-mono tracking-[0.25em] text-stone-400">
                    Atelier Classics
                  </span>
                  <h3 className="font-display text-xl tracking-[0.16em] uppercase text-stone-950 mt-1">
                    BEST SELLER CHRONICLES
                  </h3>
                </div>
                <button 
                  onClick={() => handleNavigate("shop")}
                  className="text-xs font-mono tracking-widest text-stone-900 hover:text-stone-500 underline uppercase cursor-pointer"
                >
                  Shop Best Sellers
                </button>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {bestSellers.map((p) => (
                  <div 
                    key={p.id}
                    onClick={() => handleSelectProduct(p)}
                    className="group cursor-pointer text-left flex flex-col h-full bg-white relative"
                  >
                    <div className="aspect-[3/4] bg-stone-100 overflow-hidden relative">
                      <img src={p.images[0]} alt="Bestseller" className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-103" referrerPolicy="no-referrer" />
                      <span className="absolute top-2 left-2 z-10 bg-amber-800 text-white text-[8px] font-mono tracking-widest uppercase px-2 py-0.5">BEST SELLER</span>
                    </div>
                    <div className="pt-3">
                      <h4 className="text-xs uppercase tracking-wider text-stone-900 group-hover:text-stone-500 transition-colors duration-200 line-clamp-1">{p.name}</h4>
                      <p className="text-[10px] font-mono text-stone-500 mt-1">EGP {p.price.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* EDITORIAL NEWSLETTER OPT-IN CAMPAIGNS */}
            <section className="bg-stone-50 py-16 text-center border-t border-stone-200" id="homepage-newsletter">
              <div className="max-w-2xl mx-auto px-4 space-y-6">
                <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
                  Continuous correspondence
                </span>
                <h3 className="font-display text-xl tracking-[0.15em] text-stone-950 uppercase">
                  SUBSCRIBE TO THE CHRONICLES OF DURUB
                </h3>
                <p className="text-stone-500 text-xs md:text-sm uppercase tracking-wider leading-relaxed">
                  Join other verified supporters to receive first look previews of Autumn/Winter campaigns, priority boutique alerts, and zero of any spam.
                </p>

                <form onSubmit={handleNewsletterSubmit} className="max-w-md mx-auto space-y-2">
                  <div className="flex border border-stone-300 focus-within:border-stone-900 bg-white">
                    <input
                      type="email" required
                      className="w-full text-xs bg-transparent uppercase tracking-wider py-3 px-3 focus:outline-hidden text-stone-950 font-mono"
                      placeholder="RECIPIENT@DOMINILE.COM"
                      value={newsletterEmail}
                      onChange={(e) => setNewsletterEmail(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="bg-zinc-950 hover:bg-zinc-800 text-white font-mono text-xs tracking-widest px-6 py-3 cursor-pointer uppercase font-bold"
                    >
                      OPT-IN
                    </button>
                  </div>
                  
                  {newsletterSubbed && (
                    <p className="text-[10px] font-mono text-emerald-800 tracking-widest uppercase">
                      ✓ DISPATCH ACCESS APPROVED. WELCOME TO THE CIRCLE.
                    </p>
                  )}
                </form>
              </div>
            </section>

          </div>
        )}

        {/* SHOP CAMPAIGN VIEW */}
        {currentView === "shop" && (
          <ShopView 
            products={products}
            activeCategory={categoryFilter}
            onSelectCategory={(cat) => setCategoryFilter(cat)}
            onSelectProduct={handleSelectProduct}
            searchQuery={searchQuery}
          />
        )}

        {/* DETAIL VIEW */}
        {currentView === "detail" && selectedProduct && (
          <ProductDetailView 
            product={selectedProduct}
            allProducts={products}
            onBack={() => handleNavigate("shop")}
            onAddToBag={handleAddToBag}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {/* CART & CHECKOUT SCREEN */}
        {currentView === "cart" && (
          <CartView 
            cartItems={cartItems}
            setCartItems={setCartItems}
            coupons={coupons}
            products={products}
            setProducts={setProducts}
            onSaveOrder={handleSaveNewOrderFromCheckout}
            onNavigate={handleNavigate}
            addEmailLog={addEmailLog}
          />
        )}

        {/* CUSTOMER PORTAL TRACKING VIEW */}
        {currentView === "account" && (
          <AccountView 
            orders={orders}
            onCancelOrder={handleCancelOrderFromAccount}
          />
        )}

        {/* CMS / ADMIN BACKEND PANEL VIEW (The Wix Dashboard Simulator) */}
        {currentView === "admin" && (
          <CMSDashboard 
            products={products}
            setProducts={setProducts}
            orders={orders}
            setOrders={setOrders}
            customers={customers}
            setCustomers={setCustomers}
            coupons={coupons}
            setCoupons={setCoupons}
            cmsContent={cmsContent}
            setCmsContent={setCmsContent}
            sentEmailsLog={sentEmailsLog}
            addEmailLog={addEmailLog}
          />
        )}

        {/* INFO STATIC SCREENS ROUTER */}
        {["about", "faq", "contact", "privacy", "terms"].includes(currentView) && (
          <InfoPages 
            cmsContent={cmsContent}
            viewType={currentView as any}
          />
        )}

      </main>

      {/* 5. Mobile Dynamic Sticky navigation bar */}
      <BottomNav 
        onNavigate={handleNavigate}
        currentView={currentView}
        cartCount={totalCartCount}
      />

      {/* 6. Footer section */}
      <Footer 
        onNavigate={handleNavigate}
        categories={categoriesList}
      />

    </div>
  );
}
