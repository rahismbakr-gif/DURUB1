import React, { useState } from "react";
import { Order } from "../types";
import { Package, Search, Gift, Heart, User, CheckCircle2, RefreshCw } from "lucide-react";

interface AccountViewProps {
  orders: Order[];
  onCancelOrder: (id: string) => void;
}

export function AccountView({ orders, onCancelOrder }: AccountViewProps) {
  const [searchEmail, setSearchEmail] = useState("");
  const [trackedOrders, setTrackedOrders] = useState<Order[]>(orders.slice(0, 3));
  const [searched, setSearched] = useState(false);
  const [cancellingOrderId, setCancellingOrderId] = useState<string | null>(null);
  const [cancelledAlertId, setCancelledAlertId] = useState<string | null>(null);

  // Filter orders by email
  const handleQueryOrders = (e: React.FormEvent) => {
    e.preventDefault();
    setSearched(true);
    if (!searchEmail.trim()) {
      setTrackedOrders(orders);
      return;
    }
    const filtered = orders.filter(o => 
      o.customerEmail.toLowerCase().includes(searchEmail.toLowerCase().trim()) ||
      o.id.toLowerCase().includes(searchEmail.toLowerCase().trim())
    );
    setTrackedOrders(filtered);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in" id="account-tracking-view">
      
      {/* Title */}
      <div className="border-b border-stone-200 pb-5 mb-8">
        <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
          CONCIERGE FLIGHT DEPARTURE STATUS
        </span>
        <h2 className="font-display text-2xl tracking-widest uppercase text-stone-950 mt-1">
          CUSTOMER STATION & COURIER TRACKING
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        
        {/* Left: Quick Search order tracking form */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-stone-50 p-6 border border-stone-200 space-y-4">
            <div className="flex items-center gap-2 text-stone-900 border-b pb-2">
              <User size={16} />
              <h3 className="font-mono text-[11px] tracking-widest uppercase font-bold">
                AUDIT ORDER STATUS
              </h3>
            </div>
            
            <p className="text-xs text-stone-500 uppercase leading-relaxed font-sans">
              Enter your secure customer Email address or 6-digit Order Reference ID to fetch active live shipment tracker logs instantly.
            </p>

            <form onSubmit={handleQueryOrders} className="space-y-3">
              <input
                type="text"
                required
                placeholder="REF ID / E.G. JOHN@STONE.COM"
                className="w-full text-xs font-mono uppercase tracking-widest py-3 px-3 border border-stone-300 focus:outline-hidden focus:border-stone-900 bg-white"
                value={searchEmail}
                onChange={(e) => setSearchEmail(e.target.value)}
              />
              <button
                type="submit"
                className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-mono text-xs tracking-widest uppercase font-bold inline-flex justify-center items-center gap-2 cursor-pointer"
              >
                <Search size={13} />
                <span>RETRIEVE FLIGHT</span>
              </button>
            </form>
          </div>

          {/* Loyalty membership */}
          <div className="bg-stone-50 p-6 border border-stone-200 space-y-3">
            <h4 className="font-mono text-[10px] tracking-widest uppercase text-stone-900 font-bold">
              👑 DURUB LORE PRIVILEGES
            </h4>
            <p className="text-xs text-stone-500 uppercase leading-relaxed">
              Once transactions exceed EGP 3000, accounts automatically upgrade to <span className="font-bold text-stone-950 font-mono">SILENT GOLD member status</span>, granting pre-sale gateways, 1-on-1 tailoring consults, and priority complimentary courier flights.
            </p>
          </div>
        </div>

        {/* Right side: Interactive track orders list */}
        <div className="lg:col-span-8 space-y-8Data">
          <h3 className="font-mono text-[11px] tracking-widest text-stone-900 font-bold uppercase mb-6 flex items-center gap-2">
            <Package size={15} /> ACTIVE ATELIER FLIGHT TRACKS ({trackedOrders.length})
          </h3>

          {trackedOrders.length === 0 ? (
            <div className="bg-stone-50 text-center py-12 border border-stone-200 text-stone-400 font-mono text-xs uppercase">
              {searched ? "NO CORRESPONDING DEPARTURES DETECTED IN STORAGE FOR CONCERNED RECIPIENT." : "USE SEARCH INPUT TO RETRIEVE CORRESPONDING DISPATCH FLIGHTS."}
            </div>
          ) : (
            <div className="space-y-6">
              {trackedOrders.map((ord) => (
                <div key={ord.id} className="border border-stone-200 bg-white p-5 space-y-5 shadow-xs">
                  
                  {/* Card Header details */}
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2 border-b border-stone-100 pb-3">
                    <div>
                      <span className="text-[10px] font-mono tracking-widest text-stone-900 bg-stone-50 px-2 py-0.5 border border-stone-200 uppercase font-bold">
                        ORDER REF: {ord.id}
                      </span>
                      <p className="text-[10px] font-mono text-stone-400 uppercase mt-1">
                        Timeline: {new Date(ord.date).toLocaleString()}
                      </p>
                    </div>
                    
                    <div className="text-right">
                      <span className="text-xs font-mono font-bold text-stone-950">
                        TOTAL AMOUNT: EGP {ord.total.toFixed(2)}
                      </span>
                    </div>
                  </div>

                  {/* Purchased items list */}
                  <div>
                    <span className="text-[9px] font-mono text-stone-400 uppercase tracking-widest">
                      Garments Package:
                    </span>
                    <div className="mt-1.5 flex flex-wrap gap-2">
                      {ord.items.map((it, i) => (
                        <div key={i} className="flex items-center gap-2 bg-stone-50 p-2 border border-stone-200 max-w-sm">
                          <img src={it.product.images[0]} alt="Pic" className="w-6 h-8 object-cover border" referrerPolicy="no-referrer" />
                          <div className="text-[10px] uppercase font-mono tracking-wider">
                            <p className="font-bold text-stone-900 truncate max-w-[150px]">{it.product.name}</p>
                            <p className="text-stone-500 font-bold">{it.quantity}x — {it.selectedSize} / {it.selectedColor}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Status Indicator */}
                  <div className="pt-2 border-t border-stone-100 flex justify-between items-center text-[10px] font-mono tracking-wider">
                    <span className="text-stone-400 uppercase">STATUS / الحالة:</span>
                    <span className={`font-bold uppercase ${
                      ord.status === "Cancelled" ? "text-red-600" :
                      ord.status === "Delivered" ? "text-emerald-800" :
                      "text-stone-900"
                    }`}>
                      {ord.status === "Pending" ? "PLACED / قيد الانتظار" :
                       ord.status === "Processing" ? "PREPARING / جاري التجهيز" :
                       ord.status === "Shipped" ? "DISPATCHED / تم الشحن" :
                       ord.status === "Delivered" ? "DELIVERED / تم التوصيل" :
                       "CANCELLED / ملغي"}
                    </span>
                  </div>

                  {/* Actions (Cancel if Processing) */}
                  <div className="flex justify-between items-center bg-stone-50 p-3 text-xs border-t">
                    <div className="text-[9px] font-mono text-stone-400">
                      DELIVERY DESTINATION: {ord.shippingAddress.toUpperCase()}, {ord.city.toUpperCase()}
                      {ord.trackingNumber && <span className="block text-emerald-800 font-bold font-mono uppercase">URL TRACK: {ord.trackingNumber}</span>}
                    </div>

                    {(ord.status === "Pending" || ord.status === "Processing") ? (
                      cancellingOrderId === ord.id ? (
                        <div className="flex items-center gap-2 animate-fade-in bg-red-950/20 p-1 border border-red-900/30">
                          <span className="text-[10px] font-mono text-red-400 uppercase tracking-wide">REVERSE CHARGE?</span>
                          <button
                            onClick={() => {
                              onCancelOrder(ord.id);
                              setCancellingOrderId(null);
                              setCancelledAlertId(ord.id);
                              setTimeout(() => setCancelledAlertId(null), 5000);
                            }}
                            className="bg-red-650 hover:bg-red-700 text-white text-[9px] font-mono px-2 py-0.5"
                          >
                            YES
                          </button>
                          <button
                            onClick={() => setCancellingOrderId(null)}
                            className="bg-stone-800 hover:bg-stone-750 text-stone-300 text-[9px] font-mono px-2 py-0.5"
                          >
                            NO
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setCancellingOrderId(ord.id)}
                          className="bg-red-950 hover:bg-red-900 border border-red-500/25 text-red-400 text-[10px] font-mono tracking-widest uppercase px-3 py-1 cursor-pointer"
                        >
                          Cancel Flight
                        </button>
                      )
                    ) : ord.status === "Cancelled" ? (
                      <span className="text-red-450 font-mono font-bold text-[10px] tracking-wider uppercase">
                        ✓ FLIGHT CANCELLED & REVERSED
                      </span>
                    ) : (
                      <span className="text-emerald-800 font-mono font-bold text-[10px] tracking-wider uppercase inline-flex items-center gap-1">
                        <CheckCircle2 size={12} /> Flight Completed
                      </span>
                    )}
                  </div>

                  {cancelledAlertId === ord.id && (
                    <div className="bg-red-50 text-red-800 border-t border-red-200/50 p-2.5 text-[10px] font-mono uppercase text-center animate-fade-in font-bold">
                      ✓ Flight Cancelled and Transaction Reversed successfully.
                    </div>
                  )}

                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
