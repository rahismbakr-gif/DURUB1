import React from "react";
import { Compass, ShoppingBag, User, Settings, Info } from "lucide-react";

interface BottomNavProps {
  onNavigate: (view: string, categoryFilter?: string) => void;
  currentView: string;
  cartCount: number;
}

export function BottomNav({ onNavigate, currentView, cartCount }: BottomNavProps) {
  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 py-2.5 px-4 flex justify-around items-center" id="mobile-bottom-bar">
      {/* Shop Category Trigger */}
      <button 
        onClick={() => onNavigate("shop")}
        className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
          currentView === "shop" ? "text-stone-950 font-bold" : "text-stone-400"
        }`}
      >
        <Compass size={18} />
        <span className="text-[9px] font-mono tracking-widest uppercase">COLLECTION</span>
      </button>

      {/* Shopping Bag Trigger */}
      <button 
        onClick={() => onNavigate("cart")}
        className={`flex flex-col items-center gap-1 cursor-pointer transition-colors relative ${
          currentView === "cart" ? "text-stone-950 font-bold" : "text-stone-400"
        }`}
      >
        <ShoppingBag size={18} />
        {cartCount > 0 && (
          <span className="absolute top-0 right-1 bg-stone-950 text-white text-[7px] font-mono h-3.5 w-3.5 rounded-full flex items-center justify-center font-bold">
            {cartCount}
          </span>
        )}
        <span className="text-[9px] font-mono tracking-widest uppercase">BAG</span>
      </button>

      {/* Orders/Account Screen Trigger */}
      <button 
        onClick={() => onNavigate("account")}
        className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
          currentView === "account" ? "text-stone-950 font-bold" : "text-stone-400"
        }`}
      >
        <User size={18} />
        <span className="text-[9px] font-mono tracking-widest uppercase">ORDERS</span>
      </button>

      {/* CMS Admin Portal Trigger */}
      <button 
        onClick={() => onNavigate("admin")}
        className={`flex flex-col items-center gap-1 cursor-pointer transition-colors ${
          currentView === "admin" ? "text-stone-950 font-bold" : "text-stone-400"
        }`}
      >
        <Settings size={18} />
        <span className="text-[9px] font-mono tracking-widest uppercase">STUDIO</span>
      </button>
    </div>
  );
}
