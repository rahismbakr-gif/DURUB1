import React, { useState, useEffect } from "react";
import { Product, Order, Customer, Coupon, CMSContent } from "../types";
import { 
  Package, Layout, ShieldAlert, ShoppingBag, Users, Ticket, 
  Trash2, Edit, Plus, Save, RefreshCw, Layers, Check, CheckCircle2,
  Sliders, Image as ImageIcon, Mail, FileText
} from "lucide-react";

interface CMSDashboardProps {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  orders: Order[];
  setOrders: React.Dispatch<React.SetStateAction<Order[]>>;
  customers: Customer[];
  setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
  coupons: Coupon[];
  setCoupons: React.Dispatch<React.SetStateAction<Coupon[]>>;
  cmsContent: CMSContent;
  setCmsContent: React.Dispatch<React.SetStateAction<CMSContent>>;
  sentEmailsLog: { id: string; to: string; subject: string; date: string; content: string }[];
  addEmailLog: (to: string, subject: string, content: string) => void;
}

export function CMSDashboard({
  products, setProducts,
  orders, setOrders,
  customers, setCustomers,
  coupons, setCoupons,
  cmsContent, setCmsContent,
  sentEmailsLog, addEmailLog
}: CMSDashboardProps) {
  const [activeTab, setActiveTab] = useState<'cms' | 'products' | 'orders' | 'customers' | 'coupons' | 'emails'>('products');
  
  // States for creating/editing product
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [newImageInput, setNewImageInput] = useState("");
  const [productImages, setProductImages] = useState<string[]>([]);
  const [selectedProductSizes, setSelectedProductSizes] = useState<string[]>(["S", "M", "L", "XL"]);
  const [formError, setFormError] = useState("");
  const [productToDeleteId, setProductToDeleteId] = useState<string | null>(null);
  
  // Custom drag and drop simulations and crop filters
  const [cropZoom, setCropZoom] = useState(1.0);
  const [cropContrast, setCropContrast] = useState(100);
  const [cropGrayscale, setCropGrayscale] = useState(0);

  // States for creating coupon
  const [newCoupon, setNewCoupon] = useState<Partial<Coupon>>({
    code: "",
    type: "percentage",
    value: 10,
    minSpend: 50,
    active: true
  });

  // State for Gmail automation settings
  const [gmailNotifierActive, setGmailNotifierActive] = useState(true);

  // Handle saving product edits or creations
  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct || !editingProduct.name || !editingProduct.price || !editingProduct.category) {
      setFormError("Please provide Product Name, Price, and Category.");
      setTimeout(() => setFormError(""), 5000);
      return;
    }

    const priceNum = parseFloat(editingProduct.price as any) || 0;
    const originalPriceNum = editingProduct.originalPrice ? parseFloat(editingProduct.originalPrice as any) : undefined;
    const inventoryNum = parseInt(editingProduct.inventory as any) || 0;

    const finalImages = productImages.length > 0 ? productImages : [
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=1000"
    ];

    if (editingProduct.id) {
      // Update
      const updated = products.map(p => p.id === editingProduct.id ? {
        ...p,
        name: editingProduct.name!,
        price: priceNum,
        originalPrice: originalPriceNum,
        description: editingProduct.description || "Premium fabric study.",
        category: editingProduct.category!,
        images: finalImages,
        sizes: selectedProductSizes,
        inventory: inventoryNum,
        isNew: !!editingProduct.isNew,
        isBestSeller: !!editingProduct.isBestSeller,
        featured: !!editingProduct.featured
      } as Product : p);
      setProducts(updated);
    } else {
      // Create
      const newId = `prod-${Date.now()}`;
      const createdItem: Product = {
        id: newId,
        name: editingProduct.name!,
        price: priceNum,
        originalPrice: originalPriceNum,
        description: editingProduct.description || "Minimalist luxury tailoring.",
        category: editingProduct.category!,
        images: finalImages,
        sizes: selectedProductSizes,
        colors: [
          { name: "Default Off-White", class: "bg-stone-100 border border-zinc-200" },
          { name: "Classic Noir", class: "bg-zinc-950" }
        ],
        inventory: inventoryNum,
        isNew: editingProduct.isNew ?? true,
        isBestSeller: !!editingProduct.isBestSeller,
        featured: !!editingProduct.featured
      };
      setProducts([createdItem, ...products]);
    }
    
    // Clear
    setEditingProduct(null);
    setProductImages([]);
  };

  const handleEditProductClick = (p: Product) => {
    setEditingProduct(p);
    setProductImages(p.images);
    setSelectedProductSizes(p.sizes);
  };

  const handleAddNewProductClick = () => {
    setEditingProduct({
      name: "",
      price: 0,
      description: "",
      category: "Shirts",
      inventory: 20,
      isNew: true,
      isBestSeller: false,
      featured: false
    });
    setProductImages([]);
    setSelectedProductSizes(["S", "M", "L", "XL"]);
  };

  const handleDeleteProduct = (id: string) => {
    setProductToDeleteId(id);
  };

  const deleteImage = (indexIndex: number) => {
    setProductImages(productImages.filter((_, i) => i !== indexIndex));
  };

  const addImageFromInput = () => {
    if (newImageInput.trim()) {
      setProductImages([...productImages, newImageInput.trim()]);
      setNewImageInput("");
    } else {
      setFormError("Please provide a valid image path or URL.");
      setTimeout(() => setFormError(""), 5000);
    }
  };

  const toggleSizeSelection = (size: string) => {
    if (selectedProductSizes.includes(size)) {
      setSelectedProductSizes(selectedProductSizes.filter(s => s !== size));
    } else {
      setSelectedProductSizes([...selectedProductSizes, size]);
    }
  };

  // Drag and drop mocks
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const updateImage = (section: string, chosenImg: string) => {
    if (section === "hero") {
      setCmsContent(prev => ({ ...prev, hero: { ...prev.hero, image: chosenImg } }));
    } else if (section === "product-edit") {
      setProductImages(prev => [...prev, chosenImg]);
    } else if (section === "minimalist") {
      setCmsContent(prev => ({
        ...prev,
        collectionBanners: { ...prev.collectionBanners, minimalistLineImage: chosenImg }
      }));
    } else if (section === "tailored") {
      setCmsContent(prev => ({
        ...prev,
        collectionBanners: { ...prev.collectionBanners, tailoredSuitingImage: chosenImg }
      }));
    } else if (section === "essentials") {
      setCmsContent(prev => ({
        ...prev,
        collectionBanners: { ...prev.collectionBanners, essentialsImage: chosenImg }
      }));
    } else if (section === "about") {
      setCmsContent(prev => ({ ...prev, aboutImage: chosenImg }));
    }
  };

  const handleContainerPaste = (e: React.ClipboardEvent, section: string) => {
    const items = e.clipboardData?.items;
    if (items) {
      for (let i = 0; i < items.length; i++) {
        if (items[i].type.startsWith("image/")) {
          const file = items[i].getAsFile();
          if (file) {
            const reader = new FileReader();
            reader.onload = (event) => {
              const result = event.target?.result as string;
              if (result) {
                updateImage(section, result);
              }
            };
            reader.readAsDataURL(file);
            e.preventDefault();
            return;
          }
        }
      }
    }
  };

  const handlePasteClipboardDirect = async (section: string, e?: React.MouseEvent) => {
    if (e) {
      e.stopPropagation();
    }
    try {
      const clipboardItems = await navigator.clipboard.read();
      let found = false;
      for (const item of clipboardItems) {
        for (const type of item.types) {
          if (type.startsWith("image/")) {
            const blob = await item.getType(type);
            const reader = new FileReader();
            reader.onload = (event) => {
              const result = event.target?.result as string;
              if (result) {
                updateImage(section, result);
              }
            };
            reader.readAsDataURL(blob);
            found = true;
            break;
          }
        }
        if (found) break;
      }
      if (!found) {
        alert("No image found on your clipboard! Please copy an image first, then click paste.");
      }
    } catch (err) {
      console.warn("Clipboard read permission denied/unsupported, suggesting standard Ctrl+V.", err);
      alert("To paste, select/click the target image area and press Ctrl+V (or Cmd+V on Mac) on your keyboard.");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, section: string) => {
    if (e.target.files && e.target.files.length > 0) {
      const filesList = Array.from(e.target.files);
      filesList.forEach((file) => {
        if (file.type.startsWith("image/")) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const result = event.target?.result as string;
            if (result) {
              updateImage(section, result);
            }
          };
          reader.readAsDataURL(file);
        }
      });
    }
  };

  const handleDropMock = (e: React.DragEvent, section: string) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const filesList = Array.from(e.dataTransfer.files);
      let loadedAnyRealFile = false;
      
      filesList.forEach((file) => {
        if (file.type.startsWith("image/")) {
          loadedAnyRealFile = true;
          const reader = new FileReader();
          reader.onload = (event) => {
            const result = event.target?.result as string;
            if (result) {
              updateImage(section, result);
            }
          };
          reader.readAsDataURL(file);
        }
      });
      
      if (loadedAnyRealFile) {
        return;
      }
    }

    const fashionImageMocks = [
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1479064555552-3ef4979f8908?auto=format&fit=crop&q=80&w=1200",
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&q=80&w=1000"
    ];
    const randomIndex = Math.floor(Math.random() * fashionImageMocks.length);
    const chosenImg = fashionImageMocks[randomIndex];
    updateImage(section, chosenImg);
  };

  // CMS Visual updates
  const handleUpdateCmsText = (field: string, val: string) => {
    setCmsContent(prev => {
      const copy = { ...prev };
      if (field === "hero-title") copy.hero.title = val;
      if (field === "hero-subtitle") copy.hero.subtitle = val;
      if (field === "hero-cta") copy.hero.ctaText = val;
      if (field === "promo") copy.promoMessage = val;
      if (field === "about-story") copy.aboutStory = val;
      if (field === "b-minimalist") copy.collectionBanners.minimalistLineTitle = val;
      if (field === "b-tailored") copy.collectionBanners.tailoredSuitingTitle = val;
      if (field === "b-essentials") copy.collectionBanners.essentialsTitle = val;
      return copy;
    });
  };

  // Order actions
  const handleOrderStatusUpdate = (orderId: string, status: Order['status']) => {
    const updated = orders.map(o => {
      if (o.id === orderId) {
        const timestamp = new Date().toLocaleTimeString();
        let tracking = o.trackingNumber;
        if (status === 'Shipped' && !tracking) {
          tracking = `DRB${Math.floor(100000 + Math.random() * 900000)}US`;
        }
        
        // Push live log to list
        const logContent = `Greetings ${o.customerName},\n\nYour recent DURUB luxury fashion transaction (${o.id}) has changed status to [${status.toUpperCase()}].\n\n${
          status === 'Shipped' ? `Your premium items are in global dispatch with tracking: ${tracking}` : 'Our ateliers are tailoring your garments to final precision.'
        }\n\nThank you for choosing DURUB.`;
        
        addEmailLog(o.customerEmail, `DURUB Dispatch Alert - Order ${o.id}: ${status}`, logContent);
        
        return { ...o, status, trackingNumber: tracking };
      }
      return o;
    });
    setOrders(updated);
  };

  // Create Coupon
  const handleCreateCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCoupon.code || !newCoupon.value) return;

    const coupon: Coupon = {
      id: `coun-${Date.now()}`,
      code: newCoupon.code.toUpperCase().replace(/\s+/g, ""),
      type: newCoupon.type as any,
      value: Number(newCoupon.value),
      minSpend: newCoupon.minSpend ? Number(newCoupon.minSpend) : undefined,
      active: true
    };

    setCoupons([coupon, ...coupons]);
    setNewCoupon({ code: "", type: "percentage", value: 10, minSpend: 50, active: true });
  };

  const handleToggleCoupon = (id: string) => {
    setCoupons(coupons.map(c => c.id === id ? { ...c, active: !c.active } : c));
  };

  return (
    <div className="bg-stone-900 text-stone-100 min-h-screen pb-24" id="cms-studio-layout">
      {/* CMS Header banner */}
      <div className="bg-zinc-950 border-b border-stone-800 py-10 px-4 md:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="h-2 w-2 rounded-full bg-amber-500 animate-pulse"></span>
              <span className="text-[10px] font-mono tracking-[0.25em] text-amber-500 uppercase">
                DURUB Creative Studio Core
              </span>
            </div>
            <h1 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-white">
              STUDIO PORTAL (CMS)
            </h1>
            <p className="text-stone-400 text-xs mt-1.5 uppercase tracking-wider max-w-xl">
              Configure products, design text layers, manage continuous inventories, and audit automated communications without touching code.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-4 bg-stone-900 border border-stone-800 p-3">
            <div className="flex items-center gap-2">
              <Mail className="text-amber-500" size={15} />
              <div className="text-[10px] font-mono tracking-wider">
                <p className="text-stone-300 font-bold">GMAIL BROADCASTER ACTIVE</p>
                <p className="text-[9px] text-stone-500 lowercase">to rah.ism.bakr@gmail.com</p>
              </div>
            </div>
            <button 
              onClick={() => {
                setGmailNotifierActive(!gmailNotifierActive);
              }}
              className={`px-3 py-1 font-mono text-[9px] tracking-widest border transition-colors cursor-pointer ${
                gmailNotifierActive 
                  ? "bg-amber-600/20 text-amber-400 border-amber-500/40" 
                  : "bg-stone-800 text-stone-500 border-stone-700"
              }`}
            >
              {gmailNotifierActive ? "ONLINE" : "OFFLINE"}
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 md:px-8 mt-10">
        
        {/* Navigation Sidebar Tabs */}
        <div className="flex flex-wrap gap-2 border-b border-stone-850 pb-4 mb-8">
          <button 
            onClick={() => { setActiveTab('products'); setEditingProduct(null); }}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'products' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <Package size={14} /> Catalog ({products.length})
          </button>

          <button 
            onClick={() => setActiveTab('cms')}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'cms' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <Layout size={14} /> Visual CMS (Wix Panel)
          </button>

          <button 
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'orders' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <ShoppingBag size={14} /> Orders ({orders.length})
          </button>

          <button 
            onClick={() => setActiveTab('customers')}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'customers' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <Users size={14} /> Customer Ledger
          </button>

          <button 
            onClick={() => setActiveTab('coupons')}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'coupons' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <Ticket size={14} /> Coupons ({coupons.length})
          </button>

          <button 
            onClick={() => setActiveTab('emails')}
            className={`flex items-center gap-2 px-5 py-3 font-mono text-[11px] tracking-widest uppercase transition-colors border cursor-pointer ${
              activeTab === 'emails' 
                ? "bg-stone-100 text-stone-900 border-white font-semibold" 
                : "bg-stone-900/40 text-stone-400 hover:text-white border-stone-800"
            }`}
          >
            <Mail size={14} /> Gmail Broadcaster Log ({sentEmailsLog.length})
          </button>
        </div>

        {/* TAB 1: VISUAL NO-CODE CMS EDITING (Wix Simulator) */}
        {activeTab === 'cms' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in" id="visual-cms-tab">
            {/* Editor panel left */}
            <div className="lg:col-span-6 space-y-6 bg-stone-950 p-6 border border-stone-800">
              <div className="flex items-center gap-2 border-b border-stone-850 pb-3">
                <Sliders size={16} className="text-amber-500" />
                <h3 className="text-xs font-mono tracking-widest uppercase">
                  CMS Interactive Controls
                </h3>
              </div>

              {/* Promo Banner Text */}
              <div>
                <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-2">
                  Promo Message Ribbon
                </label>
                <input 
                  type="text"
                  value={cmsContent.promoMessage}
                  onChange={(e) => handleUpdateCmsText("promo", e.target.value)}
                  className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white"
                />
              </div>

              {/* Hero Settings */}
              <div className="border-t border-stone-850 pt-4">
                <h4 className="text-[10px] font-mono tracking-widest text-amber-500 uppercase mb-4">
                  Hero Campaign Section
                </h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-[9px] font-mono text-stone-400 uppercase mb-1">
                      Hero Headline text
                    </label>
                    <input 
                      type="text"
                      value={cmsContent.hero.title}
                      onChange={(e) => handleUpdateCmsText("hero-title", e.target.value)}
                      className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white uppercase font-display"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono text-stone-400 uppercase mb-1">
                      Hero Description Text
                    </label>
                    <textarea 
                      rows={3}
                      value={cmsContent.hero.subtitle}
                      onChange={(e) => handleUpdateCmsText("hero-subtitle", e.target.value)}
                      className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono text-stone-400 uppercase mb-1">
                      CTA Button Text
                    </label>
                    <input 
                      type="text"
                      value={cmsContent.hero.ctaText}
                      onChange={(e) => handleUpdateCmsText("hero-cta", e.target.value)}
                      className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-[9px] font-mono text-stone-400 uppercase mb-1">
                      Hero Banner Image URL
                    </label>
                    <input 
                      type="text"
                      value={cmsContent.hero.image}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCmsContent(prev => ({ ...prev, hero: { ...prev.hero, image: val } }));
                      }}
                      className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white font-mono"
                    />
                    <p className="text-[8px] text-stone-500 uppercase mt-1">
                      💡 TIP: drag-and-drop simulated on the preview to inject a high-res random luxury image.
                    </p>
                  </div>
                </div>
              </div>

              {/* Showcase Banners */}
              <div className="border-t border-stone-850 pt-4 space-y-4">
                <h4 className="text-[10px] font-mono tracking-widest text-amber-500 uppercase mb-2">
                  Curated Collection Panels
                </h4>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[8px] font-mono text-stone-400 uppercase mb-1">
                      Card 1 Category title
                    </label>
                    <input 
                      type="text"
                      value={cmsContent.collectionBanners.minimalistLineTitle}
                      onChange={(e) => handleUpdateCmsText("b-minimalist", e.target.value)}
                      className="w-full bg-stone-900 border border-stone-800 p-2 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[8px] font-mono text-stone-400 uppercase mb-1">
                      Card 2 category title
                    </label>
                    <input 
                      type="text"
                      value={cmsContent.collectionBanners.tailoredSuitingTitle}
                      onChange={(e) => handleUpdateCmsText("b-tailored", e.target.value)}
                      className="w-full bg-stone-900 border border-stone-800 p-2 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              {/* Story */}
              <div className="border-t border-stone-850 pt-4">
                <h4 className="text-[10px] font-mono tracking-widest text-amber-500 uppercase mb-2">
                  Atelier Lore (About Us Story)
                </h4>
                <textarea 
                  rows={4}
                  value={cmsContent.aboutStory}
                  onChange={(e) => handleUpdateCmsText("about-story", e.target.value)}
                  className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white"
                />
              </div>
            </div>

            {/* Simulated Desktop Preview with Drag-and-Drop and Filters live left */}
            <div className="lg:col-span-6 space-y-6">
              
              <div className="bg-stone-950 p-6 border border-stone-800">
                <div className="flex items-center justify-between border-b border-stone-850 pb-3 mb-4">
                  <span className="text-xs font-mono tracking-widest text-stone-400 uppercase">
                    CMS Live Aspect Sandbox
                  </span>
                  <span className="text-[9px] font-mono text-amber-500 border border-amber-600/30 px-2 py-0.5">
                    WIX IMAGE CROPPER & FILTER STYLING
                  </span>
                </div>

                <p className="text-[10px] text-stone-500 uppercase leading-relaxed mb-4">
                  Directly adjust image scales, tone mappings, contrast filters, and crop focal ratios to perfect the luxury feel:
                </p>

                {/* Cropping filters config */}
                <div className="space-y-4 bg-stone-900 p-4 border border-stone-800 mb-6">
                  <div>
                    <div className="flex justify-between text-[9px] font-mono text-stone-400 uppercase mb-2">
                      <span>Crop Zoom / Focal point multiplier</span>
                      <span className="text-amber-500 font-bold">x {cropZoom.toFixed(2)}</span>
                    </div>
                    <input 
                      type="range" min="1" max="2" step="0.05"
                      value={cropZoom}
                      onChange={(e) => setCropZoom(parseFloat(e.target.value))}
                      className="w-full accent-amber-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-stone-400 uppercase mb-1">
                        <span>Contrast</span>
                        <span>{cropContrast}%</span>
                      </div>
                      <input 
                        type="range" min="60" max="150" step="5"
                        value={cropContrast}
                        onChange={(e) => setCropContrast(parseInt(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                    <div>
                      <div className="flex justify-between text-[9px] font-mono text-stone-400 uppercase mb-1">
                        <span>Muted Mono</span>
                        <span>{cropGrayscale}%</span>
                      </div>
                      <input 
                        type="range" min="0" max="100" step="10"
                        value={cropGrayscale}
                        onChange={(e) => setCropGrayscale(parseInt(e.target.value))}
                        className="w-full accent-amber-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Hidden file inputs for direct local file upload */}
                <input 
                  type="file" 
                  id="file-input-hero" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={(e) => handleFileChange(e, "hero")} 
                />
                <input 
                  type="file" 
                  id="file-input-minimalist" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={(e) => handleFileChange(e, "minimalist")} 
                />
                <input 
                  type="file" 
                  id="file-input-tailored" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={(e) => handleFileChange(e, "tailored")} 
                />
                <input 
                  type="file" 
                  id="file-input-essentials" 
                  accept="image/*" 
                  className="hidden" 
                  onChange={(e) => handleFileChange(e, "essentials")} 
                />

                {/* Highlight Container with drop instructions */}
                <div 
                  className="relative aspect-video bg-stone-900 border-2 border-dashed border-stone-700 hover:border-amber-500 flex flex-col justify-center items-center overflow-hidden transition-all text-center group cursor-pointer"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDropMock(e, "hero")}
                  onPaste={(e) => handleContainerPaste(e, "hero")}
                  onClick={() => document.getElementById("file-input-hero")?.click()}
                  title="Click to select image file, drag file, or press Ctrl+V to paste copied image"
                >
                  <img 
                    src={cmsContent.hero.image} 
                    alt="Hero Preview" 
                    className="absolute inset-0 w-full h-full object-cover transition-all"
                    style={{ 
                      transform: `scale(${cropZoom})`, 
                      filter: `contrast(${cropContrast}%) grayscale(${cropGrayscale}%)` 
                    }}
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-black/60 group-hover:bg-black/45 transition-colors flex flex-col justify-center items-center p-4">
                    <ImageIcon size={28} className="text-stone-300 md:group-hover:scale-110 transition-transform mb-1" />
                    <p className="text-[10px] font-mono text-stone-200 tracking-widest uppercase font-semibold">
                      CLICK, DRAG, OR PASTE (CTRL+V)
                    </p>
                    <p className="text-[8px] font-mono text-amber-400 mt-1 uppercase tracking-wider">
                      CHOOSE ANY IMAGE FILE OR PASTE DIRECTLY
                    </p>
                    <button 
                      type="button"
                      onClick={(e) => handlePasteClipboardDirect("hero", e)}
                      className="mt-2 bg-stone-905 hover:bg-stone-800 text-[8px] font-mono tracking-wider px-2 py-1 border border-stone-700 hover:border-amber-500 uppercase text-white cursor-pointer z-30"
                      title="Paste image directly from clipboard"
                    >
                      📋 Paste Copied Image
                    </button>
                  </div>
                </div>

                <div className="bg-stone-900 border border-stone-850 p-3 mt-4">
                  <p className="font-mono text-xs uppercase tracking-widest text-stone-200 mb-1">
                    {cmsContent.hero.title}
                  </p>
                  <p className="text-[10px] text-stone-400 uppercase tracking-wide line-clamp-2">
                    {cmsContent.hero.subtitle}
                  </p>
                </div>
              </div>

              {/* Three bento blocks */}
              <div className="grid grid-cols-3 gap-3">
                <div 
                  className="bg-stone-950 p-3 border border-stone-800 text-center relative aspect-square overflow-hidden cursor-pointer hover:border-amber-500 transition-colors"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDropMock(e, "minimalist")}
                  onPaste={(e) => handleContainerPaste(e, "minimalist")}
                  onClick={() => document.getElementById("file-input-minimalist")?.click()}
                  title="Click, drag, or press Ctrl+V to replace"
                >
                  <img 
                    src={cmsContent.collectionBanners.minimalistLineImage} 
                    alt="Minimalist" 
                    className="absolute inset-0 w-full h-full object-cover opacity-35"
                    referrerPolicy="no-referrer"
                  />
                  <div className="relative z-10 flex flex-col items-center justify-center h-full">
                    <span className="text-[9px] font-mono tracking-widest text-stone-300 uppercase leading-tight">
                      {cmsContent.collectionBanners.minimalistLineTitle}
                    </span>
                    <span className="text-[7px] text-amber-500 font-mono uppercase mt-1">CLICK / PASTE</span>
                    <button 
                      type="button"
                      onClick={(e) => handlePasteClipboardDirect("minimalist", e)}
                      className="mt-1.5 bg-stone-900/90 hover:bg-stone-850 text-[7px] font-mono tracking-wider px-1.5 py-0.5 border border-stone-800 uppercase text-stone-200 cursor-pointer z-30"
                    >
                      📋 PASTE
                    </button>
                  </div>
                </div>

                <div 
                  className="bg-stone-950 p-3 border border-stone-800 text-center relative aspect-square overflow-hidden cursor-pointer hover:border-amber-500 transition-colors"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDropMock(e, "tailored")}
                  onPaste={(e) => handleContainerPaste(e, "tailored")}
                  onClick={() => document.getElementById("file-input-tailored")?.click()}
                  title="Click, drag, or press Ctrl+V to replace"
                >
                  <img 
                    src={cmsContent.collectionBanners.tailoredSuitingImage} 
                    alt="Tailoring" 
                    className="absolute inset-0 w-full h-full object-cover opacity-35"
                    referrerPolicy="no-referrer"
                  />
                  <div className="relative z-10 flex flex-col items-center justify-center h-full">
                    <span className="text-[9px] font-mono tracking-widest text-stone-300 uppercase leading-tight">
                      {cmsContent.collectionBanners.tailoredSuitingTitle}
                    </span>
                    <span className="text-[7px] text-amber-500 font-mono uppercase mt-1">CLICK / PASTE</span>
                    <button 
                      type="button"
                      onClick={(e) => handlePasteClipboardDirect("tailored", e)}
                      className="mt-1.5 bg-stone-900/90 hover:bg-stone-850 text-[7px] font-mono tracking-wider px-1.5 py-0.5 border border-stone-800 uppercase text-stone-200 cursor-pointer z-30"
                    >
                      📋 PASTE
                    </button>
                  </div>
                </div>

                <div 
                  className="bg-stone-950 p-3 border border-stone-800 text-center relative aspect-square overflow-hidden cursor-pointer hover:border-amber-500 transition-colors"
                  onDragOver={handleDragOver}
                  onDrop={(e) => handleDropMock(e, "essentials")}
                  onPaste={(e) => handleContainerPaste(e, "essentials")}
                  onClick={() => document.getElementById("file-input-essentials")?.click()}
                  title="Click, drag, or press Ctrl+V to replace"
                >
                  <img 
                    src={cmsContent.collectionBanners.essentialsImage} 
                    alt="Essentials" 
                    className="absolute inset-0 w-full h-full object-cover opacity-35"
                    referrerPolicy="no-referrer"
                  />
                  <div className="relative z-10 flex flex-col items-center justify-center h-full">
                    <span className="text-[9px] font-mono tracking-widest text-stone-300 uppercase leading-tight">
                      {cmsContent.collectionBanners.essentialsTitle}
                    </span>
                    <span className="text-[7px] text-amber-500 font-mono uppercase mt-1">CLICK / PASTE</span>
                    <button 
                      type="button"
                      onClick={(e) => handlePasteClipboardDirect("essentials", e)}
                      className="mt-1.5 bg-stone-900/90 hover:bg-stone-850 text-[7px] font-mono tracking-wider px-1.5 py-0.5 border border-stone-800 uppercase text-stone-200 cursor-pointer z-30"
                    >
                      📋 PASTE
                    </button>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* TAB 2: PRODUCT CATALOG MANAGEMENT */}
        {activeTab === 'products' && (
          <div className="space-y-6 animate-fade-in" id="product-ledger-tab">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div>
                <h3 className="text-sm font-mono tracking-widest text-white uppercase">
                  MASTER PRODUCT LEDGER & STOCK METRICS
                </h3>
                <p className="text-stone-400 text-xs mt-1 uppercase tracking-wide">
                  Create, update pricing thresholds, manage sizes, and modify active inventory lines instantly.
                </p>
              </div>

              <button 
                onClick={handleAddNewProductClick}
                className="bg-amber-500 hover:bg-amber-600 text-stone-950 text-xs font-mono tracking-widest uppercase font-bold py-3 px-6 inline-flex items-center gap-2 transition-all cursor-pointer"
              >
                <Plus size={16} /> CREATE NEW GARMENT
              </button>
            </div>

            {/* Product Edit / Creation Modal Drawer */}
            {editingProduct && (
              <form onSubmit={handleSaveProduct} className="bg-stone-950 p-6 border border-amber-600/40 space-y-6">
                <div className="flex justify-between items-center border-b border-stone-800 pb-3">
                  <h4 className="text-xs font-mono tracking-widest uppercase text-amber-500">
                    {editingProduct.id ? `EDITING: ${editingProduct.name}` : "REGISTER NEW CATALOG ITEM"}
                  </h4>
                  <button 
                    type="button" 
                    onClick={() => setEditingProduct(null)}
                    className="text-stone-400 hover:text-white font-mono text-[10px] tracking-wider cursor-pointer"
                  >
                    ✕ CANCEL
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Part 1 */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                        Garment Title
                      </label>
                      <input 
                        type="text" 
                        required
                        placeholder="e.g. FINE-KNIT CASUAL VEST"
                        value={editingProduct.name || ""}
                        onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value.toUpperCase() })}
                        className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5 uppercase font-mono tracking-wide"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                          Price (EGP)
                        </label>
                        <input 
                          type="number" 
                          step="0.01"
                          required
                          value={editingProduct.price || 0}
                          onChange={(e) => setEditingProduct({ ...editingProduct, price: parseFloat(e.target.value) })}
                          className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5 font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                          Original Price (EGP)
                        </label>
                        <input 
                          type="number" 
                          step="0.01"
                          placeholder="If on sale"
                          value={editingProduct.originalPrice || ""}
                          onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: e.target.value ? parseFloat(e.target.value) : undefined })}
                          className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5 font-mono"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                        Category Drawer
                      </label>
                      <select 
                        value={editingProduct.category || "Shirts"}
                        onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value })}
                        className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5 uppercase font-mono tracking-wide"
                      >
                        <option value="T-Shirts">T-Shirts</option>
                        <option value="Shirts">Shirts</option>
                        <option value="Jeans">Jeans</option>
                        <option value="Trousers">Trousers</option>
                        <option value="Jackets">Jackets</option>
                        <option value="Shoes">Shoes</option>
                        <option value="Accessories">Accessories</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                        Active Inventory (Units)
                      </label>
                      <input 
                        type="number" 
                        required
                        value={editingProduct.inventory ?? 10}
                        onChange={(e) => setEditingProduct({ ...editingProduct, inventory: parseInt(e.target.value) })}
                        className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5 font-mono"
                      />
                    </div>
                  </div>

                  {/* Part 2: Descriptions & Tags */}
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                        Description Specs
                      </label>
                      <textarea 
                        rows={4}
                        placeholder="Fibre characteristics, fit detailing, atelier origin"
                        value={editingProduct.description || ""}
                        onChange={(e) => setEditingProduct({ ...editingProduct, description: e.target.value })}
                        className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2.5"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-2">
                        Product Sizing Matrices
                      </label>
                      <div className="flex flex-wrap gap-2">
                        {["S", "M", "L", "XL", "XXL", "30", "31", "32", "34", "41", "42", "43", "44", "45", "One Size"].map((sz) => (
                          <button
                            type="button"
                            key={sz}
                            onClick={() => toggleSizeSelection(sz)}
                            className={`px-3 py-1 text-[9px] font-mono tracking-wider transition-all cursor-pointer ${
                              selectedProductSizes.includes(sz)
                                ? "bg-white text-stone-950 font-bold border-white"
                                : "bg-stone-900 text-stone-500 border border-stone-850"
                            }`}
                          >
                            {sz}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox"
                          checked={!!editingProduct.isNew}
                          onChange={(e) => setEditingProduct({ ...editingProduct, isNew: e.target.checked })}
                          className="accent-amber-500"
                        />
                        <span className="text-[10px] font-mono tracking-wider text-stone-300">TAG AS NEW ARRIVAL</span>
                      </label>

                      <label className="flex items-center gap-2 cursor-pointer">
                        <input 
                          type="checkbox"
                          checked={!!editingProduct.isBestSeller}
                          onChange={(e) => setEditingProduct({ ...editingProduct, isBestSeller: e.target.checked })}
                          className="accent-amber-500"
                        />
                        <span className="text-[10px] font-mono tracking-wider text-stone-300">TAG AS BEST SELLER</span>
                      </label>
                    </div>
                  </div>

                  {/* Part 3: Image Galleries uploading */}
                  <div className="space-y-4">
                    <label className="block text-[10px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                      Interactive Product Gallery (Multiple Images)
                    </label>

                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="/images/your-image.jpg or URL..."
                        value={newImageInput}
                        onChange={(e) => setNewImageInput(e.target.value)}
                        className="w-full bg-stone-900 border border-stone-800 text-xs text-white p-2 font-mono"
                      />
                      <button
                        type="button"
                        onClick={addImageFromInput}
                        className="bg-stone-800 hover:bg-stone-700 text-white text-[10px] font-mono px-3 cursor-pointer"
                      >
                        ADD
                      </button>
                      <button
                        type="button"
                        onClick={(e) => handlePasteClipboardDirect("product-edit", e)}
                        className="bg-zinc-950 hover:bg-stone-800 text-[10px] text-amber-500 font-mono border border-stone-800 px-3 cursor-pointer whitespace-nowrap flex items-center gap-1 font-bold"
                        title="Paste copied image from clipboard directly"
                      >
                        📋 PASTE IMAGE
                      </button>
                    </div>

                    <p className="text-[8px] text-stone-500 uppercase">
                      Paste fashion links, CLICK PASTE IMAGE to inject a copied file, or Drag image onto the dotted area below.
                    </p>

                    {/* Hidden file input for product edit multiple select */}
                    <input 
                      type="file" 
                      id="file-input-product-edit" 
                      accept="image/*" 
                      className="hidden" 
                      multiple 
                      onChange={(e) => handleFileChange(e, "product-edit")} 
                    />

                    {/* Drag and Drop simulation list */}
                    <div 
                      className="border border-dashed border-stone-800 p-4 min-h-[90px] flex flex-wrap gap-2 items-center justify-center bg-stone-900/30 cursor-pointer hover:border-amber-500 transition-colors"
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDropMock(e, "product-edit")}
                      onPaste={(e) => handleContainerPaste(e, "product-edit")}
                      onClick={() => document.getElementById("file-input-product-edit")?.click()}
                      title="Click to select multiple files, drop files, or press Ctrl+V to paste copied image"
                    >
                      {productImages.length === 0 ? (
                        <div className="text-center text-stone-600">
                          <ImageIcon size={20} className="mx-auto mb-1 opacity-55" />
                          <span className="text-[9px] font-mono uppercase">CLICK, DROP FILES OR PRESS CTRL+V TO PASTE IMAGE</span>
                        </div>
                      ) : (
                        productImages.map((img, i) => (
                          <div key={i} className="relative w-12 h-16 bg-stone-950 border border-stone-800" onClick={(e) => e.stopPropagation()}>
                            <img src={img} alt="Thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); deleteImage(i); }}
                              className="absolute -top-1 -right-1 h-3.5 w-3.5 bg-red-650 hover:bg-red-700 text-white text-[8px] flex items-center justify-center font-bold"
                            >
                              ✕
                            </button>
                          </div>
                        ))
                      )}
                    </div>

                    {/* Direct Image URL Editors */}
                    {productImages.length > 0 && (
                      <div className="space-y-2 border-t border-stone-850/50 pt-3.5">
                        <span className="block text-[9px] font-mono text-stone-400 uppercase tracking-widest font-bold">
                          Active Gallery Image URLs (Edit/Replace directly):
                        </span>
                        <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                          {productImages.map((img, i) => (
                            <div key={i} className="flex items-center gap-2 bg-stone-900/45 p-1.5 border border-stone-850">
                              <span className="text-[9px] font-mono text-stone-500 font-bold">#{i + 1}</span>
                              <img src={img} alt="Preview" className="w-6 h-8 object-cover border border-stone-800" referrerPolicy="no-referrer" />
                              <input 
                                type="text"
                                value={img}
                                onChange={(e) => {
                                  const updated = [...productImages];
                                  updated[i] = e.target.value;
                                  setProductImages(updated);
                                }}
                                className="flex-1 bg-stone-950 border border-stone-800 text-[10px] text-white p-1 font-mono rounded-none focus:outline-hidden focus:border-stone-700"
                                placeholder="https://unsplash.com/..."
                              />
                              <button
                                type="button"
                                onClick={() => deleteImage(i)}
                                className="h-5 w-5 bg-stone-800 hover:bg-red-950 hover:text-red-400 text-stone-400 text-[10px] flex items-center justify-center font-bold"
                                title="Remove image"
                              >
                                ✕
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {formError && (
                  <div className="bg-red-95/10 text-red-400 border border-red-900/30 p-2.5 text-[10px] font-mono uppercase text-right tracking-widest">
                    ⚠ {formError}
                  </div>
                )}

                <div className="flex justify-between items-center border-t border-stone-850 pt-4">
                  {editingProduct.id ? (
                    <button 
                      type="button"
                      onClick={() => {
                        if (confirm(`Are you sure you want to delete "${editingProduct.name}"?`)) {
                          setProducts(products.filter(item => item.id !== editingProduct.id));
                          setEditingProduct(null);
                        }
                      }}
                      className="bg-red-950/40 text-red-400 border border-red-900/40 hover:bg-red-900 hover:text-white text-xs font-mono tracking-widest uppercase px-5 py-2.5 cursor-pointer font-semibold"
                    >
                      DELETE PRODUCT
                    </button>
                  ) : (
                    <div />
                  )}
                  <div className="flex gap-3">
                    <button 
                      type="button"
                      onClick={() => setEditingProduct(null)}
                      className="bg-stone-900 text-stone-400 hover:text-white border border-stone-800 text-xs font-mono tracking-widest uppercase px-5 py-2.5 cursor-pointer"
                    >
                      CANCEL
                    </button>
                    <button 
                      type="submit"
                      className="bg-white text-stone-950 font-bold hover:bg-stone-200 text-xs font-mono tracking-widest uppercase px-6 py-2.5 cursor-pointer inline-flex items-center gap-2"
                    >
                      <Save size={14} /> SAVE PRODUCT
                    </button>
                  </div>
                </div>
              </form>
            )}

            {/* List Table */}
            <div className="bg-stone-950 border border-stone-800 overflow-x-auto">
              <table className="w-full text-left text-xs tracking-wider">
                <thead className="bg-stone-900 text-[10px] font-mono tracking-widest uppercase text-stone-400 border-b border-stone-800">
                  <tr>
                    <th className="p-4">SKU / Preview</th>
                    <th className="p-4">Garment Title</th>
                    <th className="p-4">Category</th>
                    <th className="p-4">Price / Sale</th>
                    <th className="p-4 text-center">Sizes</th>
                    <th className="p-4 text-center">Stock Status</th>
                    <th className="p-4 text-right">Operations</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-905">
                  {products.map((p) => {
                    const isOutOfStock = p.inventory <= 0;
                    return (
                      <tr key={p.id} className="hover:bg-stone-900/40 text-stone-300">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <span className="text-[9px] font-mono text-stone-500 whitespace-nowrap">{p.id}</span>
                            <img 
                              src={p.images[0]} 
                              alt="Garment" 
                              className="w-10 h-12 object-cover bg-stone-100 border border-stone-800"
                              referrerPolicy="no-referrer"
                            />
                          </div>
                        </td>
                        <td className="p-4 font-semibold text-white uppercase">{p.name}</td>
                        <td className="p-4 text-stone-400 uppercase">{p.category}</td>
                        <td className="p-4 font-mono">
                          <div className="flex flex-col">
                            <span>EGP {p.price.toFixed(2)}</span>
                            {p.originalPrice && (
                              <span className="text-[10px] text-stone-500 line-through">EGP {p.originalPrice.toFixed(2)}</span>
                            )}
                          </div>
                        </td>
                        <td className="p-4 text-center">
                          <div className="flex flex-wrap justify-center gap-1 max-w-[200px] mx-auto">
                            {p.sizes.map((s) => (
                              <span key={s} className="bg-stone-900 text-stone-400 text-[9px] font-mono px-1 py-0.5 border border-stone-850">
                                {s}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="p-4 text-center">
                          <div className="flex flex-col items-center">
                            <span className={`text-[10px] font-mono tracking-widest px-2.5 py-0.5 text-center font-bold uppercase rounded-sm ${
                              isOutOfStock 
                                ? "bg-red-950 text-red-400 border border-red-900/30" 
                                : p.inventory <= 5 
                                  ? "bg-amber-950 text-amber-500 border border-amber-900/30 font-bold animate-pulse" 
                                  : "bg-emerald-950 text-emerald-400 border border-emerald-900/30"
                            }`}>
                              {isOutOfStock ? "DELETED/OUT" : `${p.inventory} UNITS`}
                            </span>
                          </div>
                        </td>
                        <td className="p-4 text-right">
                          {productToDeleteId === p.id ? (
                            <div className="flex items-center justify-end gap-1.5 bg-red-950/40 p-1 border border-red-900/30 w-fit ml-auto animate-fade-in">
                              <span className="text-[9px] font-mono text-red-400 uppercase font-bold">RETIRE?</span>
                              <button 
                                onClick={() => {
                                  setProducts(products.filter(item => item.id !== p.id));
                                  setProductToDeleteId(null);
                                }}
                                className="bg-red-650 hover:bg-red-700 text-white text-[9px] font-mono px-1.5 py-0.5 cursor-pointer font-bold"
                              >
                                YES
                              </button>
                              <button 
                                onClick={() => setProductToDeleteId(null)}
                                className="bg-stone-800 hover:bg-stone-750 text-stone-300 text-[9px] font-mono px-1.5 py-0.5 cursor-pointer font-bold"
                              >
                                NO
                              </button>
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <button 
                                onClick={() => handleEditProductClick(p)}
                                className="p-1 px-2 hover:bg-stone-800 text-stone-300 hover:text-amber-500 transition-colors uppercase font-mono text-[10px] inline-flex items-center gap-1 cursor-pointer"
                                title="Edit specifications"
                              >
                                <Edit size={12} /> Edit
                              </button>
                              <button 
                                onClick={() => handleDeleteProduct(p.id)}
                                className="p-1 px-2 hover:bg-red-950/20 text-stone-500 hover:text-red-455 transition-colors uppercase font-mono text-[10px] inline-flex items-center gap-1 cursor-pointer"
                                title="Retire from database"
                              >
                                <Trash2 size={12} /> Delete
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* TAB 3: ORDER DISPATCH STATUS LIST */}
        {activeTab === 'orders' && (
          <div className="space-y-6 animate-fade-in" id="order-ledger-tab">
            <div>
              <h3 className="text-sm font-mono tracking-widest text-white uppercase">
                DISPATCH FLIGHT & SALES LEDGER
              </h3>
              <p className="text-stone-400 text-xs mt-1 uppercase tracking-wide">
                Track payments, update courier status, write custom tracking metrics, and monitor automated updates to clients.
              </p>
            </div>

            <div className="space-y-4">
              {orders.length === 0 ? (
                <div className="bg-stone-950 text-center py-12 border border-stone-800 text-stone-500 font-mono text-xs uppercase">
                  NO SALES TRANSACTION RECORDS DETECTED IN STORAGE.
                </div>
              ) : (
                orders.map((or) => (
                  <div key={or.id} className="bg-stone-950 border border-stone-800 p-5 space-y-4">
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-stone-900 pb-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="font-mono text-sm text-white uppercase font-bold tracking-wider">
                            ID: {or.id}
                          </span>
                          <span className="text-[10px] font-mono text-stone-500">
                            {new Date(or.date).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-400 uppercase tracking-widest mt-1">
                          BUYER: {or.customerName} ({or.customerEmail})
                        </p>
                      </div>

                      {/* Status selectors */}
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-mono text-stone-500 uppercase tracking-wider">
                          COURIER FLIGHT STATUS:
                        </span>
                        {(['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'] as Order['status'][]).map((st) => (
                          <button
                            key={st}
                            onClick={() => handleOrderStatusUpdate(or.id, st)}
                            className={`px-3 py-1 font-mono text-[9px] tracking-widest uppercase transition-colors rounded-none border cursor-pointer ${
                              or.status === st
                                ? st === 'Delivered' 
                                  ? "bg-emerald-950 text-emerald-400 border-emerald-500/40 font-bold"
                                  : st === 'Cancelled'
                                    ? "bg-red-950 text-red-400 border-red-500/40"
                                    : "bg-amber-500 text-stone-950 font-bold border-amber-600"
                                : "bg-stone-900 text-stone-500 border-stone-800 hover:text-white"
                            }`}
                          >
                            {st}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Order Details & Addresses */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      
                      {/* Column 1: Items */}
                      <div>
                        <span className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-2">
                          GARMENTS APPORTIONED
                        </span>
                        <ul className="space-y-2">
                          {or.items.map((i, idx) => (
                            <li key={idx} className="flex gap-2 text-xs uppercase">
                              <span className="font-mono text-amber-500">[{i.quantity}x]</span>
                              <span className="text-white font-medium line-clamp-1 flex-grow">{i.product.name}</span>
                              <span className="text-stone-400 font-mono">({i.selectedSize}/{i.selectedColor})</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 2: Address */}
                      <div>
                        <span className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-2">
                          SHIPPING PORTION
                        </span>
                        <div className="text-xs text-stone-400 uppercase leading-relaxed font-mono">
                          <p>{or.shippingAddress}</p>
                          <p>{or.city}, {or.zipCode}</p>
                          <p>TEL: {or.customerPhone}</p>
                        </div>
                      </div>

                      {/* Column 3: Total ledger */}
                      <div>
                        <span className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-2">
                          FINANCIAL LEDGER
                        </span>
                        <div className="text-[11px] font-mono space-y-1 bg-stone-900 p-2.5 border border-stone-850">
                          <div className="flex justify-between">
                            <span>Subtotal</span>
                            <span>EGP {or.subtotal.toFixed(2)}</span>
                          </div>
                          {or.discount > 0 && (
                            <div className="flex justify-between text-amber-550">
                              <span>Coupon ({or.couponApplied})</span>
                              <span>-EGP {or.discount.toFixed(2)}</span>
                            </div>
                          )}
                          <div className="flex justify-between border-t border-stone-800 pt-1 font-bold text-white text-xs">
                            <span>FINAL OUTFLOW</span>
                            <span>EGP {or.total.toFixed(2)}</span>
                          </div>
                        </div>

                        {or.trackingNumber && (
                          <p className="text-[9px] font-mono text-emerald-400 mt-2 uppercase tracking-widest">
                            ✓ TRACK COURIER: {or.trackingNumber}
                          </p>
                        )}
                      </div>

                    </div>
                  </div>
                ))
              )}
            </div>

          </div>
        )}

        {/* TAB 4: CUSTOMERS DATABASE */}
        {activeTab === 'customers' && (
          <div className="space-y-6 animate-fade-in" id="customer-ledger-tab">
            <div>
              <h3 className="text-sm font-mono tracking-widest text-white uppercase">
                CUSTOMER DIRECTORY & PROFILES
              </h3>
              <p className="text-stone-400 text-xs mt-1 uppercase tracking-wide">
                Manage accounts, review join timelines, audit shopping frequency, and contact records.
              </p>
            </div>

            <div className="bg-stone-950 border border-stone-800">
              <table className="w-full text-left text-xs tracking-wider">
                <thead className="bg-stone-900 text-[10px] font-mono tracking-widest uppercase text-stone-400 border-b border-stone-800">
                  <tr>
                    <th className="p-4">Customer Name / ID</th>
                    <th className="p-4">Secure Email</th>
                    <th className="p-4">Joined Timeline</th>
                    <th className="p-4">Coordinates</th>
                    <th className="p-4 text-center">Transactions count</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-905">
                  {customers.map((c) => (
                    <tr key={c.id} className="hover:bg-stone-900/40 text-stone-300">
                      <td className="p-4">
                        <div className="flex flex-col">
                          <span className="font-bold text-white">{c.name}</span>
                          <span className="text-[9px] font-mono text-stone-500">{c.id}</span>
                        </div>
                      </td>
                      <td className="p-4 font-mono font-medium">{c.email}</td>
                      <td className="p-4 text-stone-400">{new Date(c.createdAt).toLocaleDateString()}</td>
                      <td className="p-4 font-mono text-[11px] text-stone-400 uppercase">
                        {c.address}
                        {c.phone && <span className="block text-[10px] text-stone-500">TEL: {c.phone}</span>}
                      </td>
                      <td className="p-4 text-center font-mono font-bold text-amber-500">
                        {c.orders.length} ORDERS
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* TAB 5: COUPONS */}
        {activeTab === 'coupons' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-fade-in" id="coupons-tab">
            
            {/* Create form */}
            <div className="bg-stone-950 p-6 border border-stone-850 h-fit space-y-5">
              <h4 className="text-xs font-mono tracking-widest text-white uppercase border-b border-stone-800 pb-2">
                CREATE TAILORED SPECIAL OFFER KEY
              </h4>

              <form onSubmit={handleCreateCoupon} className="space-y-4">
                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                    Coupon Promo Code
                  </label>
                  <input 
                    type="text"
                    required
                    placeholder="e.g. SILENT50"
                    value={newCoupon.code || ""}
                    onChange={(e) => setNewCoupon({ ...newCoupon, code: e.target.value.toUpperCase() })}
                    className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white font-mono uppercase"
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                    Discount Type
                  </label>
                  <select 
                    value={newCoupon.type}
                    onChange={(e) => setNewCoupon({ ...newCoupon, type: e.target.value as any })}
                    className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white font-mono uppercase"
                  >
                    <option value="percentage">Percentage ( % )</option>
                    <option value="fixed">Fixed Balance Deduction ( EGP )</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                    Value Tag
                  </label>
                  <input 
                    type="number"
                    required
                    value={newCoupon.value || ""}
                    onChange={(e) => setNewCoupon({ ...newCoupon, value: parseFloat(e.target.value) })}
                    className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-400 uppercase mb-1">
                    Minimum Activation Spend (EGP) [Optional]
                  </label>
                  <input 
                    type="number"
                    value={newCoupon.minSpend || ""}
                    onChange={(e) => setNewCoupon({ ...newCoupon, minSpend: e.target.value ? parseFloat(e.target.value) : undefined })}
                    className="w-full bg-stone-900 border border-stone-800 p-2.5 text-xs text-white font-mono"
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full bg-white text-stone-950 font-bold hover:bg-stone-200 text-xs font-mono tracking-widest uppercase py-3 cursor-pointer"
                >
                  ✓ DEPLOY PROMO KEY
                </button>
              </form>
            </div>

            {/* List */}
            <div className="lg:col-span-2 space-y-4">
              <h4 className="text-xs font-mono tracking-widest text-white uppercase">
                DEPLOYED CAMPAIGN PROMOS
              </h4>

              <div className="bg-stone-950 border border-stone-800 divide-y divide-stone-900">
                {coupons.map((cop) => (
                  <div key={cop.id} className="p-4 flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-sm tracking-widest font-bold text-white bg-stone-900 px-2 py-1 border border-stone-800">
                          {cop.code}
                        </span>
                        <span className={`text-[9px] font-mono font-bold tracking-widest px-2.5 py-0.5 uppercase ${
                          cop.active ? "bg-emerald-950 text-emerald-400" : "bg-stone-900 text-stone-500"
                        }`}>
                          {cop.active ? "ACTIVE" : "RETIRED"}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-400 mt-2 uppercase font-mono">
                        Deducts {cop.type === "percentage" ? `${cop.value}%` : `EGP ${cop.value}`} off {cop.minSpend ? `orders over EGP ${cop.minSpend}` : "all baskets"}
                      </p>
                    </div>

                    <button 
                      onClick={() => handleToggleCoupon(cop.id)}
                      className={`text-[9px] font-mono px-3.5 py-1.5 uppercase transition-colors border cursor-pointer ${
                        cop.active 
                          ? "bg-red-950 hover:bg-red-900 text-red-400 border-red-500/30" 
                          : "bg-emerald-950 hover:bg-emerald-900 text-emerald-400 border-emerald-500/30"
                      }`}
                    >
                      {cop.active ? "Deactivate" : "Activate"}
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* TAB 6: EMAIL BROADCASTER LOG */}
        {activeTab === 'emails' && (
          <div className="space-y-6 animate-fade-in" id="emails-log-tab">
            <div className="bg-stone-950 p-6 border border-stone-800">
              <div className="flex items-center justify-between border-b border-stone-850 pb-3 mb-6">
                <div>
                  <h3 className="text-sm font-mono tracking-widest text-white uppercase">
                    GMAIL NOTIFICATION ENGINE DEPLOYMENTS
                  </h3>
                  <p className="text-stone-500 text-xs mt-1 uppercase tracking-wide">
                    The DURUB transaction systems automatically route receipt PDFs and courier codes to `rah.ism.bakr@gmail.com` and customer mailboxes.
                  </p>
                </div>
                <span className="bg-emerald-950 text-emerald-400 border border-emerald-900 px-3 py-1 text-[10px] uppercase font-mono font-semibold">
                  MOCK GMAIL API ACTIVE (OK)
                </span>
              </div>

              {sentEmailsLog.length === 0 ? (
                <div className="text-center py-10 text-stone-500 font-mono text-xs uppercase border border-dashed border-stone-850">
                  NO GMAIL SECURE BROADCASTS SENT IN THE RECENT SESSION.
                </div>
              ) : (
                <div className="space-y-4">
                  {sentEmailsLog.map((log) => (
                    <div key={log.id} className="bg-stone-900 border border-stone-850 p-4 space-y-2">
                      <div className="flex flex-col md:flex-row justify-between text-[10px] font-mono text-stone-400 border-b border-stone-800 pb-2">
                        <p>
                          <span className="text-amber-500">RECIPIENT:</span> {log.to}
                        </p>
                        <p className="text-stone-500">{log.date}</p>
                      </div>
                      <h4 className="text-xs font-mono font-bold text-white uppercase tracking-wider">
                        SUBJECT: {log.subject}
                      </h4>
                      <pre className="text-[11px] text-stone-300 font-sans leading-relaxed whitespace-pre-wrap bg-stone-950 p-3 mt-2 border border-stone-900">
                        {log.content}
                      </pre>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
