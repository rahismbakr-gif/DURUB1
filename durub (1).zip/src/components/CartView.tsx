import React, { useState, useMemo } from "react";
import { OrderItem, Coupon, Order, Product, Customer } from "../types";
import {
  Trash2,
  AlertCircle,
  ShieldCheck,
  Ticket,
  CheckSquare,
  Compass,
} from "lucide-react";

interface CartViewProps {
  cartItems: OrderItem[];
  setCartItems: React.Dispatch<React.SetStateAction<OrderItem[]>>;
  coupons: Coupon[];
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  onSaveOrder: (newOrder: Order) => void;
  onNavigate: (view: string) => void;
  addEmailLog: (to: string, subject: string, content: string) => void;
}

export function CartView({
  cartItems,
  setCartItems,
  coupons,
  products,
  setProducts,
  onSaveOrder,
  onNavigate,
  addEmailLog,
}: CartViewProps) {
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState("");

  // Checkout coordinates states
  const [customerName, setCustomerName] = useState("Rahma Ismail Bakr");
  const [customerEmail, setCustomerEmail] = useState("rah.ism.bakr@gmail.com");
  const [customerPhone, setCustomerPhone] = useState("+20 100 123 4567");
  const [shippingAddress, setShippingAddress] = useState("Alsalam 1, Suez");
  const [city, setCity] = useState("Suez");
  const [zipCode, setZipCode] = useState("Alsalam 1");

  // Step navigation state for Arabic checkout flow
  const [checkoutStep, setCheckoutStep] = useState(1); // 1 = Location, 2 = Info, 3 = Confirmation
  const [firstName, setFirstName] = useState("Rahma");
  const [lastName, setLastName] = useState("Ismail Bakr");
  const [couponInputText, setCouponInputText] = useState("");

  const cityAreas: { [key: string]: string[] } = {
    Suez: ["Alsalam 1", "Arbaeen", "Faisal", "Attaka"],
    Cairo: ["Zamalek", "Maadi", "Heliopolis", "Tagamoa El Khames"],
    Giza: ["Dokki", "Mohandessin", "Haram", "6th of October"],
    Alexandria: ["Smouha", "Sidi Gaber", "Montaza", "Maamoura"],
  };

  const handleApplyCouponInline = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setCouponError("");
    const code = couponInputText.toUpperCase().trim();
    const match = coupons.find((c) => c.code === code && c.active);

    if (!match) {
      setCouponError("كود الخصم غير صحيح أو منتهي الصلاحية.");
      setAppliedCoupon(null);
      return;
    }

    if (match.minSpend && subtotal < match.minSpend) {
      setCouponError(
        `هذا الكود يتطلب حد أدنى للشراء بقيمة EGP ${match.minSpend}.`,
      );
      setAppliedCoupon(null);
      return;
    }

    setAppliedCoupon(match);
    setCouponInputText("");
  };

  // Payment simulations
  const [cardNumber, setCardNumber] = useState("4000123456789010");
  const [cardExpiry, setCardExpiry] = useState("12/28");
  const [cardCVV, setCardCVV] = useState("123");

  const [checkoutSucceeded, setCheckoutSucceeded] = useState<Order | null>(
    null,
  );
  const [checkoutError, setCheckoutError] = useState("");

  const subtotal = useMemo(() => {
    return cartItems.reduce((acc, current) => {
      return acc + current.product.price * current.quantity;
    }, 0);
  }, [cartItems]);

  const discountAmount = useMemo(() => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.minSpend && subtotal < appliedCoupon.minSpend) {
      return 0; // Does not qualify
    }
    if (appliedCoupon.type === "percentage") {
      return (subtotal * appliedCoupon.value) / 100;
    } else {
      return appliedCoupon.value;
    }
  }, [appliedCoupon, subtotal]);

  const finalTotal = useMemo(() => {
    return Math.max(subtotal - discountAmount, 0);
  }, [subtotal, discountAmount]);

  const handleUpdateQuantity = (idx: number, qty: number) => {
    if (qty <= 0) return;
    const copied = [...cartItems];
    copied[idx].quantity = qty;
    setCartItems(copied);
  };

  const handleRemove = (idx: number) => {
    setCartItems(cartItems.filter((_, i) => i !== idx));
  };

  // Applying promo keys
  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError("");
    const code = couponCode.toUpperCase().trim();
    const match = coupons.find((c) => c.code === code && c.active);

    if (!match) {
      setCouponError("PROMO KEY UNRECOGNIZED OR DEACTIVATED.");
      setAppliedCoupon(null);
      return;
    }

    if (match.minSpend && subtotal < match.minSpend) {
      setCouponError(`REQUIRES MINIMUM SPEND OF EGP ${match.minSpend}.`);
      setAppliedCoupon(null);
      return;
    }

    setAppliedCoupon(match);
    setCouponCode("");
  };

  const handleClearCoupon = () => {
    setAppliedCoupon(null);
    setCouponError("");
  };

  // Checkout submission
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (cartItems.length === 0) return;

    if (!customerEmail.includes("@")) {
      setCheckoutError("Please specify a valid Email.");
      return;
    }

    // Generate Order Flight
    const orderId = `order-${Math.floor(1000 + Math.random() * 9000)}`;
    const trackingNo = `DRB${Math.floor(100000 + Math.random() * 900000)}US`;

    const newOrder: Order = {
      id: orderId,
      customerName,
      customerEmail,
      customerPhone,
      shippingAddress,
      city,
      zipCode,
      items: cartItems,
      subtotal,
      discount: discountAmount,
      total: finalTotal,
      date: new Date().toISOString(),
      status: "Processing",
      trackingNumber: trackingNo,
      couponApplied: appliedCoupon?.code,
    };

    // 1. Decrement Stock levels of purchased files
    const updatedProductsList = products.map((origProduct) => {
      const purchasedMatch = cartItems.find(
        (i) => i.product.id === origProduct.id,
      );
      if (purchasedMatch) {
        return {
          ...origProduct,
          inventory: Math.max(
            origProduct.inventory - purchasedMatch.quantity,
            0,
          ),
        };
      }
      return origProduct;
    });
    setProducts(updatedProductsList);

    // 2. Add email mock logs for client receipts
    const orderDetailsListString = cartItems
      .map(
        (i) =>
          `• ${i.product.name} (QTY: ${i.quantity}) - SIZE: ${i.selectedSize}, COLOR: ${i.selectedColor}`,
      )
      .join("\n");

    const emailBody = `AUTHENTIC DURUB RECEIPT RECORD

Hello ${customerName},

Thank you for choosing DURUB. Our atelier team has initiated preparations to wrap and dispatch your physical garments with the utmost attention.

Order Confirmation: ${orderId}
Dispatch Courier Tracking Code: ${trackingNo}
Shipping Destination: ${shippingAddress}, ${city}

GARMENT LEDGER:
${orderDetailsListString}

Subtotal: EGP ${subtotal.toFixed(2)}
Discount Applied: -EGP ${discountAmount.toFixed(2)}
Final Paid Inflow: EGP ${finalTotal.toFixed(2)}

Track your flight courier anytime on our portal under "Customer Station" or reply to this message for bespoke adjustments.`;

    // Send notifications to client email
    addEmailLog(
      customerEmail,
      `DURUB Receipt - Thank you for your purchase (${orderId})`,
      emailBody,
    );

    // Send copy to admin rah.ism.bakr@gmail.com
    const adminBodyLog = `DURUB STUDIO NEW INBOUND ORDER METRIC DETECTED
    
Order Key: ${orderId}
Buyer: ${customerName} (${customerEmail})
Coordinates: ${shippingAddress}, ${city}, ZIP: ${zipCode}

Garments:
${orderDetailsListString}

Total Outflow: EGP ${finalTotal.toFixed(2)}
Coupon Used: ${appliedCoupon?.code || "None"}`;

    addEmailLog(
      "rah.ism.bakr@gmail.com",
      `[ATELIER ALERT] New Secure Transaction - ${orderId}`,
      adminBodyLog,
    );

    // Save Order card securely in list
    onSaveOrder(newOrder);

    // Success state
    setCheckoutSucceeded(newOrder);
    setCartItems([]); // clear cart
  };

  if (checkoutSucceeded) {
    return (
      <div
        className="max-w-3xl mx-auto px-4 py-16 text-center animate-fade-in"
        id="receipt-screen"
      >
        <div className="border border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 p-8 md:p-12 space-y-8 shadow-xs">
          <div className="inline-flex items-center justify-center h-16 w-16 bg-stone-950 dark:bg-stone-100 text-white dark:text-stone-950 rounded-full mb-2">
            <CheckSquare size={32} />
          </div>

          <div>
            <span className="text-[10px] font-mono tracking-widest text-amber-500 uppercase">
              Atelier Transaction Succeeded
            </span>
            <h2 className="font-display text-2xl tracking-[0.15em] text-stone-950 dark:text-stone-100 uppercase mt-2">
              GARMENTS CONFIRMED
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400 uppercase tracking-widest mt-1.5 font-mono">
              ORDER REFERENCE : {checkoutSucceeded.id}
            </p>
          </div>

          <div className="border-y border-stone-200 dark:border-stone-800 py-6 text-left space-y-4 max-w-lg mx-auto">
            <p className="text-xs uppercase tracking-wider text-stone-600 dark:text-stone-450 leading-relaxed font-mono">
              ✓ GMAIL NOTIFICATION TRANSMITTED SUCCESSFULLY to both{" "}
              <span className="font-bold text-stone-900 dark:text-stone-100 font-mono">
                {checkoutSucceeded.customerEmail}
              </span>{" "}
              and{" "}
              <span className="font-bold text-stone-950 dark:text-stone-200 font-mono">
                rah.ism.bakr@gmail.com
              </span>{" "}
              for immediate auditing.
            </p>

            <div className="bg-stone-50 dark:bg-stone-950 p-4 border border-stone-200 dark:border-stone-800 text-xs text-stone-500 dark:text-stone-400 uppercase space-y-1.5">
              <p>
                <span className="font-bold text-zinc-900 dark:text-stone-350 font-mono">
                  Courier:
                </span>{" "}
                DURUB Global Express Express
              </p>
              <p>
                <span className="font-bold text-zinc-900 dark:text-stone-350 font-mono">
                  Tracking Code:
                </span>{" "}
                {checkoutSucceeded.trackingNumber}
              </p>
              <p>
                <span className="font-bold text-zinc-900 dark:text-stone-350 font-mono">
                  Expected ETA:
                </span>{" "}
                2-4 Business Days
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => onNavigate("account")}
              className="w-full md:w-auto bg-stone-950 hover:bg-zinc-800 text-white font-mono text-xs tracking-widest uppercase px-8 py-3.5 cursor-pointer"
            >
              TRACK FLIGHT STATUS
            </button>
            <br />
            <button
              onClick={() => onNavigate("shop")}
              className="font-mono text-xs text-stone-500 uppercase tracking-widest underline hover:text-stone-950 cursor-pointer inline-block mt-4"
            >
              Continue Exploring Collections
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in"
      id="cart-screen"
    >
      <h2 className="font-display text-2xl tracking-widest uppercase text-stone-950 dark:text-stone-100 mb-8 border-b border-stone-200 dark:border-stone-800 pb-4">
        SHOPPING BAG
      </h2>

      {cartItems.length === 0 ? (
        <div className="text-center py-20 bg-stone-50 dark:bg-stone-900 border border-stone-200/50 dark:border-stone-800">
          <p className="text-stone-400 dark:text-stone-500 text-xs font-mono tracking-widest uppercase mb-6">
            Your container is currently void of garments.
          </p>
          <button
            onClick={() => onNavigate("shop")}
            className="bg-zinc-950 dark:bg-stone-100 hover:bg-zinc-800 dark:hover:bg-stone-200 text-white dark:text-stone-950 font-mono text-xs tracking-widest uppercase px-8 py-3.5 inline-flex items-center gap-2 cursor-pointer"
          >
            <Compass size={14} /> EXPLORE THE CURRENT CAMPAIGN
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Cart items list left column */}
          <div className="lg:col-span-7 space-y-6">
            <div className="divide-y divide-stone-200 border-b border-stone-200">
              {cartItems.map((item, idx) => (
                <div key={idx} className="py-5 flex gap-4 md:gap-6 items-start">
                  {/* Photo spacer */}
                  <img
                    src={item.product.images[0]}
                    alt={item.product.name}
                    className="w-20 md:w-24 aspect-[3/4] object-cover bg-stone-150 border"
                    referrerPolicy="no-referrer"
                  />

                  {/* Descriptions block */}
                  <div className="flex-grow flex flex-col md:flex-row justify-between gap-4">
                    <div className="space-y-1">
                      <h3 className="text-xs md:text-sm font-semibold uppercase tracking-wider text-stone-950 dark:text-stone-100">
                        {item.product.name}
                      </h3>
                      <p className="text-[10px] text-stone-400 dark:text-stone-500 font-mono uppercase tracking-widest">
                        SIZE: {item.selectedSize} / COLOR: {item.selectedColor}
                      </p>
                      <p className="text-xs text-stone-500 dark:text-stone-400 font-mono mt-2 pt-1 border-t border-stone-100 dark:border-stone-900 w-fit">
                        EGP {item.product.price.toFixed(2)} EACH
                      </p>
                    </div>

                    <div className="flex items-center md:flex-col justify-between md:items-end gap-3 self-end md:self-auto">
                      {/* Quantity adjusting */}
                      <div className="flex border border-stone-300 dark:border-stone-700">
                        <button
                          onClick={() =>
                            handleUpdateQuantity(idx, item.quantity - 1)
                          }
                          className="px-2 py-1 bg-stone-50 dark:bg-stone-900 hover:bg-stone-150 dark:hover:bg-stone-850 text-stone-500 font-bold border-r border-stone-300 dark:border-stone-750 pr-2.5 cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-3.5 py-1 text-xs self-center font-mono text-stone-950 dark:text-stone-50">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            handleUpdateQuantity(idx, item.quantity + 1)
                          }
                          className="px-2 py-1 bg-stone-50 dark:bg-stone-900 hover:bg-stone-150 dark:hover:bg-stone-850 text-stone-500 font-bold border-l border-stone-300 dark:border-stone-750 pl-2.5 cursor-pointer"
                        >
                          +
                        </button>
                      </div>

                      {/* Remove */}
                      <button
                        onClick={() => handleRemove(idx)}
                        className="text-stone-400 hover:text-red-700 p-1 flex items-center justify-between pointer-events-auto cursor-pointer font-mono text-[9px] uppercase tracking-widest gap-1"
                        title="Remove silhouette"
                      >
                        <Trash2 size={12} /> Remove
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Promo Codes applying block */}
            <form
              onSubmit={handleApplyCoupon}
              className="flex gap-2 max-w-sm mt-4"
            >
              <input
                type="text"
                placeholder="PROMO CODE (e.g. DURUB10)"
                className="w-full text-xs font-mono uppercase tracking-widest py-3 px-3 border border-stone-350 focus:outline-hidden focus:border-black bg-white"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value)}
              />
              <button
                type="submit"
                className="bg-zinc-950 hover:bg-zinc-850 text-white font-mono text-xs uppercase px-5 tracking-widest cursor-pointer"
              >
                APPLY
              </button>
            </form>

            {couponError && (
              <p className="text-[10px] font-mono text-red-500 uppercase tracking-widest mt-1.5 flex items-center gap-1">
                <AlertCircle size={10} /> {couponError}
              </p>
            )}

            {appliedCoupon && (
              <div className="bg-emerald-50 text-emerald-800 border border-emerald-250 py-2 px-3 flex justify-between items-center text-[10px] font-mono tracking-widest uppercase mt-2.5">
                <span>
                  ✓ PROMO KEY [{appliedCoupon.code}] EQUIPPED (-EGP{" "}
                  {discountAmount.toFixed(2)})
                </span>
                <button
                  type="button"
                  onClick={handleClearCoupon}
                  className="underline font-bold text-emerald-950 cursor-pointer"
                >
                  [REMOVE]
                </button>
              </div>
            )}
          </div>

          {/* Right column: Multi-step checkout form coordinates and metrics */}
          <div className="lg:col-span-5 space-y-6">
            {/* Outflow Metrics Box */}
            <div className="bg-stone-50 p-6 border border-stone-200 space-y-4">
              <h3 className="font-mono text-[11px] tracking-widest text-stone-900 font-bold uppercase border-b border-stone-300 pb-2">
                BAG OUTFLOW METRIC
              </h3>

              <div className="text-xs uppercase space-y-2 font-mono">
                <div className="flex justify-between text-stone-500">
                  <span>Bag Items Subtotal</span>
                  <span>EGP {subtotal.toFixed(2)}</span>
                </div>

                {discountAmount > 0 && (
                  <div className="flex justify-between text-amber-800 font-bold">
                    <span>Coupon Deductions</span>
                    <span>-EGP {discountAmount.toFixed(2)}</span>
                  </div>
                )}

                <div className="flex justify-between text-stone-500">
                  <span>Standard Cargo Flight</span>
                  <span className="text-emerald-800">
                    {subtotal >= 1500 ? "FREE" : "EGP 150.00"}
                  </span>
                </div>

                <div className="flex justify-between text-stone-950 font-bold text-sm border-t pt-3.5">
                  <span>FINAL FLOW</span>
                  <span>
                    EGP{" "}
                    {(finalTotal + (subtotal >= 1500 ? 0 : 150.0)).toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            {/* Checkout user coordinates Form */}
            <div
              className="bg-white text-stone-900 p-6 md:p-8 border border-stone-200 space-y-6 rounded-none"
              dir="rtl"
            >
              {/* Step indicator */}
              <div className="flex items-center justify-between w-full max-w-xs mx-auto mb-8 font-mono">
                {/* Step 3 (Leftmost in RTL) */}
                <div className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full border text-xs font-bold transition-all duration-300 ${
                      checkoutStep === 3
                        ? "bg-stone-950 border-stone-950 text-white"
                        : "bg-white border-stone-200 text-stone-400"
                    }`}
                  >
                    ٣
                  </div>
                </div>

                {/* Connecting line 2-3 */}
                <div
                  className={`h-[1px] flex-1 transition-all duration-300 ${
                    checkoutStep === 3 ? "bg-stone-950" : "bg-stone-200"
                  }`}
                />

                {/* Step 2 (Middle) */}
                <div className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full border text-xs font-bold transition-all duration-300 ${
                      checkoutStep >= 2
                        ? "bg-stone-950 border-stone-950 text-white"
                        : "bg-white border-stone-200 text-stone-400"
                    }`}
                  >
                    {checkoutStep > 2 ? "✓" : "٢"}
                  </div>
                </div>

                {/* Connecting line 1-2 */}
                <div
                  className={`h-[1px] flex-1 transition-all duration-300 ${
                    checkoutStep >= 2 ? "bg-stone-950" : "bg-stone-200"
                  }`}
                />

                {/* Step 1 (Rightmost in RTL) */}
                <div className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-8 h-8 rounded-full border text-xs font-bold transition-all duration-300 ${
                      checkoutStep >= 1
                        ? "bg-stone-950 border-stone-950 text-white"
                        : "bg-white border-stone-200 text-stone-400"
                    }`}
                  >
                    {checkoutStep > 1 ? "✓" : "١"}
                  </div>
                </div>
              </div>

              {/* Step 1: Delivery Location */}
              {checkoutStep === 1 && (
                <div className="space-y-5 animate-fade-in">
                  <h3 className="text-sm font-mono tracking-widest text-stone-900 text-center uppercase border-b border-stone-100 pb-3 font-bold">
                    مكان التوصيل / LOCATION
                  </h3>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      المدينة / CITY
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: السويس"
                      value={city}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCity(val);
                        setShippingAddress(`${zipCode}, ${val}`);
                      }}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 focus:outline-hidden focus:border-stone-950 font-sans text-right"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      المنطقة / AREA
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: السلام ١"
                      value={zipCode}
                      onChange={(e) => {
                        const val = e.target.value;
                        setZipCode(val);
                        setShippingAddress(`${val}, ${city}`);
                      }}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 focus:outline-hidden focus:border-stone-950 font-sans text-right"
                    />
                  </div>

                  <div className="pt-4">
                    <button
                      type="button"
                      onClick={() => setCheckoutStep(2)}
                      className="w-full bg-stone-950 hover:bg-stone-850 text-white py-3.5 rounded-none font-mono font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer"
                    >
                      استمرار / CONTINUE
                    </button>
                  </div>
                </div>
              )}

              {/* Step 2: Delivery Info */}
              {checkoutStep === 2 && (
                <div className="space-y-4 animate-fade-in">
                  <h3 className="text-sm font-mono tracking-widest text-stone-900 text-center uppercase border-b border-stone-100 pb-3 font-bold">
                    معلومات التوصيل / DELIVERY INFO
                  </h3>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      الاسم الأول / FIRST NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={firstName}
                      onChange={(e) => {
                        setFirstName(e.target.value);
                        setCustomerName(`${e.target.value} ${lastName}`);
                      }}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 placeholder-stone-400 focus:outline-hidden focus:border-stone-950 text-right font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      الاسم الأخير / LAST NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={lastName}
                      onChange={(e) => {
                        setLastName(e.target.value);
                        setCustomerName(`${firstName} ${e.target.value}`);
                      }}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 placeholder-stone-400 focus:outline-hidden focus:border-stone-950 text-right font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      الهاتف / PHONE NUMBER
                    </label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 placeholder-stone-400 focus:outline-hidden focus:border-stone-950 text-right font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-mono tracking-wider text-stone-500 mb-1.5 text-right font-bold uppercase">
                      العنوان بالتفصيل / ADDRESS DETAILS
                    </label>
                    <input
                      type="text"
                      required
                      value={shippingAddress}
                      onChange={(e) => setShippingAddress(e.target.value)}
                      className="w-full text-xs bg-stone-50 border border-stone-200 rounded-none py-3 px-4 text-stone-900 placeholder-stone-400 focus:outline-hidden focus:border-stone-950 text-right font-sans"
                    />
                  </div>

                  {checkoutError && (
                    <p className="text-red-500 text-[10px] text-right font-mono uppercase tracking-widest">
                      ⚠ {checkoutError}
                    </p>
                  )}

                  <div className="flex gap-4 pt-4">
                    <button
                      type="button"
                      onClick={() => {
                        if (
                          !firstName.trim() ||
                          !lastName.trim() ||
                          !customerPhone.trim() ||
                          !shippingAddress.trim()
                        ) {
                          setCheckoutError("يرجى ملء جميع الحقول المطلوبة.");
                          return;
                        }
                        setCheckoutError("");
                        setCheckoutStep(3);
                      }}
                      className="flex-1 bg-stone-950 hover:bg-stone-850 text-white py-3.5 rounded-none font-mono font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer"
                    >
                      استمرار / CONTINUE
                    </button>
                    <button
                      type="button"
                      onClick={() => setCheckoutStep(1)}
                      className="flex-1 bg-stone-100 hover:bg-stone-200 text-stone-700 py-3.5 rounded-none font-mono font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer"
                    >
                      رجوع / BACK
                    </button>
                  </div>
                </div>
              )}

              {/* Step 3: Order Summary & Placement */}
              {checkoutStep === 3 && (
                <form
                  onSubmit={handleCheckoutSubmit}
                  className="space-y-5 animate-fade-in"
                >
                  <h3 className="text-sm font-mono tracking-widest text-stone-900 text-center uppercase border-b border-stone-100 pb-3 font-bold">
                    تأكيد الطلب / CONFIRM ORDER
                  </h3>

                  <div className="bg-stone-50 p-4 rounded-none border border-stone-200 text-xs space-y-3 font-sans text-right">
                    <div className="flex justify-between border-b border-stone-200 pb-2 text-stone-500 font-mono text-[10px] tracking-widest uppercase">
                      <span className="font-bold text-stone-900">
                        البيانات الشخصية
                      </span>
                      <span>المستلم</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">الاسم:</span>
                      <span className="font-bold text-stone-900">
                        {customerName}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">الهاتف:</span>
                      <span className="font-bold text-stone-900 font-mono">
                        {customerPhone}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">العنوان:</span>
                      <span className="font-bold text-stone-900">
                        {shippingAddress}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">الموقع:</span>
                      <span className="font-bold text-stone-900">
                        {city} ({zipCode})
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-stone-200 pt-2 text-stone-500">
                      <span className="font-bold text-stone-900">طريقة الدفع:</span>
                      <span className="font-bold text-emerald-800 font-mono text-[10px] tracking-widest uppercase">
                        💵 الدفع عند الاستلام (COD)
                      </span>
                    </div>
                  </div>

                  <div className="bg-stone-50 p-4 rounded-none border border-stone-200 text-xs space-y-2 font-sans text-right">
                    <div className="flex justify-between border-b border-stone-200 pb-2 text-stone-500 font-mono text-[10px] tracking-widest uppercase">
                      <span className="font-bold text-stone-900">
                        الملخص المالي
                      </span>
                      <span>المبلغ</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-stone-500">مجموع المشتريات:</span>
                      <span className="text-stone-900 font-mono">
                        EGP {subtotal.toFixed(2)}
                      </span>
                    </div>
                    {discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-800 font-bold">
                        <span>الخصم المطبق:</span>
                        <span className="font-mono">-EGP {discountAmount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-stone-500">مصاريف الشحن:</span>
                      <span className="text-stone-900">
                        {subtotal >= 1500 ? "مجاني" : "EGP 150.00"}
                      </span>
                    </div>
                    <div className="flex justify-between border-t border-stone-200 pt-3.5 text-sm font-bold text-stone-900">
                      <span>المجموع الكلي:</span>
                      <span className="text-stone-950 font-mono font-bold text-sm">
                        EGP{" "}
                        {(finalTotal + (subtotal >= 1500 ? 0 : 150.0)).toFixed(
                          2,
                        )}
                      </span>
                    </div>
                  </div>

                  {checkoutError && (
                    <p className="text-red-500 text-xs text-right font-mono">
                      ⚠ {checkoutError}
                    </p>
                  )}

                  <div className="space-y-3 pt-2">
                    <button
                      type="submit"
                      className="w-full bg-stone-950 hover:bg-stone-850 text-white py-3.5 rounded-none font-mono font-bold text-xs tracking-widest uppercase transition-all cursor-pointer text-center flex items-center justify-center gap-2"
                    >
                      <span>تأكيد وطلب الشراء / PLACE COD ORDER</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setCheckoutStep(2)}
                      className="w-full bg-stone-100 hover:bg-stone-200 text-stone-700 py-3.5 rounded-none font-mono font-bold text-xs tracking-widest uppercase transition-colors cursor-pointer"
                    >
                      رجوع لتعديل البيانات / BACK TO EDIT
                    </button>
                  </div>
                </form>
              )}

              <p className="text-[9px] text-stone-450 uppercase tracking-wide leading-relaxed text-center font-mono py-1 border-t border-stone-100 pt-3">
                🔒 ATELIER LOGISTICS NOTE: YOUR GARMENTS WILL BE DISPATCHED VIA PRIVATE COURIER. GMAIL NOTIFICATIONS AUTO-ROUTE INSTANT COPIES TO RAH.ISM.BAKR@GMAIL.COM.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
