import React, { useState } from "react";

interface FooterProps {
  onNavigate: (view: string, categoryFilter?: string) => void;
  categories: string[];
}

export function Footer({ onNavigate, categories }: FooterProps) {
  const [email, setEmail] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes("@")) {
      setSuccess(true);
      setEmail("");
      setTimeout(() => setSuccess(false), 5000);
    }
  };

  return (
    <footer className="bg-stone-50 border-t border-stone-200 text-stone-900 pt-16 pb-12 mt-auto" id="main-footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Main Columns Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Column 1: Store Lore */}
          <div className="flex flex-col">
            <h4 className="font-display font-medium tracking-[0.3em] uppercase text-sm mb-6 text-stone-950">
              DURUB
            </h4>
            <p className="text-xs text-stone-500 tracking-wide leading-relaxed mb-4 uppercase">
              Tactile permanence. Architected garments crafted in limited structural runs. Inspired by master craftsmanship.
            </p>
            <div className="flex flex-col gap-2 mt-2">
              <span className="text-[10px] font-mono text-zinc-400 tracking-widest">
                PARIS / MILAN / TOKYO / NEW YORK
              </span>
              <a 
                href="https://durub.com" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-[10px] font-mono text-stone-950 hover:text-stone-500 tracking-widest uppercase underline transition-colors w-fit font-semibold"
              >
                DURUB.COM
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h5 className="text-[11px] font-mono tracking-widest text-stone-950 uppercase mb-6">
              COLLECTIONS
            </h5>
            <ul className="space-y-3.5 text-xs tracking-wider">
              <li>
                <button 
                  onClick={() => onNavigate("shop", undefined)} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Shop All Garments
                </button>
              </li>
              {categories.slice(0, 5).map((cat) => (
                <li key={cat}>
                  <button 
                    onClick={() => onNavigate("shop", cat)} 
                    className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                  >
                    {cat} Collections
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Customer Service Core */}
          <div>
            <h5 className="text-[11px] font-mono tracking-widest text-stone-950 uppercase mb-6">
              STATION (SUPPORT)
            </h5>
            <ul className="space-y-3.5 text-xs tracking-wider">
              <li>
                <button 
                  onClick={() => onNavigate("about")} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Our Essence Story
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigate("faq")} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Frequently Asked
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigate("contact")} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Contact Concierge
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigate("privacy")} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Security & Privacy
                </button>
              </li>
              <li>
                <button 
                  onClick={() => onNavigate("terms")} 
                  className="text-stone-500 hover:text-stone-950 uppercase text-left transition-colors cursor-pointer"
                >
                  Terms of Service
                </button>
              </li>
            </ul>
          </div>

          {/* Column 4: Newsletter signup */}
          <div>
            <h5 className="text-[11px] font-mono tracking-widest text-stone-950 uppercase mb-6">
              THE DURUB DISPATCH
            </h5>
            <p className="text-xs text-stone-500 tracking-wide leading-relaxed mb-4 uppercase">
              Join to receive private campaigns, collection arrivals, and atelier chronicles.
            </p>

            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="flex border border-stone-350 focus-within:border-stone-900 bg-white">
                <input
                  type="email"
                  placeholder="CHRONICLE@RECIPIENT.COM"
                  className="w-full text-xs bg-transparent uppercase tracking-wider py-2.5 px-3 focus:outline-hidden text-stone-950 font-mono"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
                <button 
                  type="submit"
                  className="bg-zinc-950 text-white hover:bg-zinc-800 text-[10px] tracking-widest font-mono uppercase px-4 cursor-pointer"
                >
                  JOIN
                </button>
              </div>
              
              {success && (
                <p className="text-[10px] font-mono text-emerald-800 tracking-widest uppercase mt-2">
                  ✓ DISPATCH OPT-IN ACCOMPLISHED. WELCOME.
                </p>
              )}
            </form>
          </div>
        </div>

        {/* Bottom Bar: Clean payments structure & copyright */}
        <div className="border-t border-stone-200/60 pt-10 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-[10px] font-mono text-stone-400 tracking-widest uppercase">
            © {new Date().getFullYear()} DURUB ATELIER. CODES DESIGNED FOR PERMANENCE. ALL RIGHTS RESERVED.
          </div>
          
          <div className="flex gap-4 opacity-55 hover:opacity-85 transition-opacity duration-300">
            <span className="text-[9px] font-mono text-stone-500 border border-stone-300 px-2.5 py-1 tracking-widest uppercase rounded-sm">
              VISA SECURE
            </span>
            <span className="text-[9px] font-mono text-stone-500 border border-stone-300 px-2.5 py-1 tracking-widest uppercase rounded-sm">
              AMEX ENCRYPTED
            </span>
            <span className="text-[9px] font-mono text-stone-500 border border-stone-300 px-2.5 py-1 tracking-widest uppercase rounded-sm">
              APPLE PAY
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
