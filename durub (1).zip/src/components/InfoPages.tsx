import React, { useState } from "react";
import { CMSContent } from "../types";
import { Mail, Phone, MapPin, Compass, ShieldAlert, FileText, Send, Check } from "lucide-react";

interface InfoPagesProps {
  cmsContent: CMSContent;
  viewType: 'about' | 'faq' | 'contact' | 'privacy' | 'terms';
}

export function InfoPages({ cmsContent, viewType }: InfoPagesProps) {
  // Contact state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [msg, setMsg] = useState("");
  const [contactSuccess, setContactSuccess] = useState(false);

  // FAQ state active tracker
  const [activeFaqIdx, setActiveFaqIdx] = useState<number | null>(null);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setContactSuccess(true);
    setName("");
    setEmail("");
    setMsg("");
    setTimeout(() => setContactSuccess(false), 5000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-12 md:py-16 animate-fade-in" id="info-pages-wrapper">
      
      {/* 1. ABOUT US PAGE */}
      {viewType === 'about' && (
        <section className="space-y-10" id="essence-about-section">
          <div className="text-center space-y-3">
            <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
              Our Spatial Manifestations
            </span>
            <h1 className="font-display text-3xl md:text-4xl font-light tracking-[0.2em] text-stone-950 uppercase">
              THE ESSENCE OF DURUB
            </h1>
            <div className="h-0.5 w-16 bg-zinc-900 mx-auto"></div>
          </div>

          <div className="prose prose-stone mx-auto max-w-2xl text-center space-y-6">
            <p className="text-stone-650 leading-relaxed uppercase text-sm tracking-widest">
              "{cmsContent.aboutStory}"
            </p>
          </div>

          <div className="aspect-[16/9] overflow-hidden bg-stone-100 border border-stone-200">
            <img 
              src={cmsContent.aboutImage} 
              alt="Atelier Study" 
              className="w-full h-full object-cover grayscale brightness-95 opacity-85 hover:grayscale-0 transition-all duration-[2000ms]"
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs text-stone-500 uppercase mt-12 pt-8 border-t">
            <div className="space-y-2">
              <h4 className="font-bold text-stone-950 font-mono text-[10px] tracking-widest">
                01 / MASTER WEAVER METRIC
              </h4>
              <p className="leading-relaxed">
                By maintaining partnerships with family-operated mills in Okayama and Biella, we access exclusive compact linen, dry-touch worsted wools, and organic seersucker cotton before global distribution blocks.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-stone-950 font-mono text-[10px] tracking-widest">
                02 / ARCHITECTURAL ENGINEERING
              </h4>
              <p className="leading-relaxed">
                Each collection garment undergoes intensive spatial fitting tests. We draft sleeve pitches and back box pleats mathematically to accommodate human action without losing structured drape rigidity.
              </p>
            </div>
          </div>
        </section>
      )}

      {/* 2. FAQS PAGE */}
      {viewType === 'faq' && (
        <section className="space-y-10" id="faq-section">
          <div className="border-b border-stone-200 pb-5">
            <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
              Client Concierge Guidelines
            </span>
            <h1 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-stone-950 uppercase mt-1">
              FREQUENTLY ASKED LORE
            </h1>
          </div>

          <div className="space-y-4">
            {cmsContent.faqs.map((f, i) => (
              <div key={i} className="border border-stone-200 bg-white">
                <button
                  type="button"
                  onClick={() => setActiveFaqIdx(activeFaqIdx === i ? null : i)}
                  className="w-full py-4.5 px-6 flex justify-between items-center text-left text-xs uppercase tracking-wider font-semibold text-stone-950 hover:bg-stone-50 transition-colors cursor-pointer"
                >
                  <span className="font-mono text-zinc-400 mr-3">[{f.category}]</span>
                  <span className="flex-grow">{f.question}</span>
                  <span className="text-sm font-mono text-stone-400 ml-4 font-bold">
                    {activeFaqIdx === i ? "[-]" : "[+]"}
                  </span>
                </button>

                {activeFaqIdx === i && (
                  <div className="p-6 pt-0 border-t border-stone-100 text-xs text-stone-500 uppercase tracking-widest leading-relaxed bg-stone-50/50">
                    {f.answer}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 3. CONTACT PAGE */}
      {viewType === 'contact' && (
        <section className="space-y-10" id="contact-section">
          <div className="border-b border-stone-200 pb-5 text-center">
            <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
              Bespoke Assistance
            </span>
            <h1 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-stone-950 uppercase mt-1">
              CONTACT ATELIER CONCIERGE
            </h1>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            
            {/* Form details */}
            <div className="bg-stone-50 p-6 md:p-8 border border-stone-250/60 space-y-6">
              <span className="block text-[10px] font-mono tracking-widest text-stone-900 font-bold uppercase border-b pb-2">
                TRANSMIT SECURE INQUIRY
              </span>

              <form onSubmit={handleContactSubmit} className="space-y-4">
                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-1">
                    Your Name
                  </label>
                  <input 
                    type="text" required
                    className="w-full text-xs bg-white py-2.5 px-3 border border-stone-250 focus:outline-hidden text-stone-950"
                    placeholder="e.g. Johnathan Stone"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-1">
                    Secure Email Address
                  </label>
                  <input 
                    type="email" required
                    className="w-full text-xs bg-white py-2.5 px-3 border border-stone-250 focus:outline-hidden text-stone-950"
                    placeholder="e.g. j@stone.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-[9px] font-mono tracking-widest text-stone-500 uppercase mb-1">
                    Your Message Detail
                  </label>
                  <textarea 
                    rows={4} required
                    className="w-full text-xs bg-white py-2.5 px-3 border border-stone-250 focus:outline-hidden text-stone-950"
                    placeholder="Inquire about sizing, custom batches, or trade parameters..."
                    value={msg}
                    onChange={(e) => setMsg(e.target.value)}
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-3 bg-zinc-950 hover:bg-zinc-800 text-white font-mono text-xs tracking-widest uppercase font-bold inline-flex justify-center items-center gap-2 cursor-pointer"
                >
                  <Send size={13} />
                  <span>TRANSMIT DISPATCH</span>
                </button>

                {contactSuccess && (
                  <div className="bg-emerald-50 text-emerald-800 border border-emerald-250 p-3 text-[9px] font-mono tracking-widest uppercase text-center animate-fade-in">
                    ✓ TRANSMISSION SUCCEEDED. CONCIERGE CHRONICLES ROUTED TO RECIPIENT.
                  </div>
                )}
              </form>
            </div>

            {/* Coordinates info */}
            <div className="space-y-8">
              <div className="space-y-4">
                <span className="block text-[10px] font-mono tracking-widest text-stone-900 font-bold uppercase border-b pb-2">
                  ATELIER DEPARTURES
                </span>
                
                <div className="space-y-4 text-xs uppercase text-stone-550 leading-relaxed font-mono">
                  <div className="flex items-start gap-3">
                    <MapPin size={16} className="text-stone-700 mt-0.5" />
                    <div>
                      <p className="font-bold text-stone-950">DURUB ATELIER HEADQUARTERS</p>
                      <p>24 Rue Saint-Honoré, 75001 Paris, France</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Mail size={16} className="text-stone-700 mt-0.5" />
                    <div>
                      <p className="font-bold text-stone-950 font-mono">CHRONICLES BROADCASTS</p>
                      <p className="lowercase">concierge@durub.com</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Phone size={16} className="text-stone-700 mt-0.5" />
                    <div>
                      <p className="font-bold text-stone-950 font-mono">TELEPHONE COORDINATE</p>
                      <p>+33 1 40 20 50 50</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-stone-50 p-4 border text-[10px] uppercase text-stone-500 leading-relaxed font-mono">
                <p className="font-bold text-stone-950 mb-1">⏱️ CONCIERGE RESPONSE INTERVALS</p>
                <p>Monday - Friday: 09:00 - 18:00 CET</p>
                <p>Saturday: 10:00 - 15:00 CET</p>
              </div>
            </div>

          </div>
        </section>
      )}

      {/* 4. PRIVACY POLICY */}
      {viewType === 'privacy' && (
        <section className="space-y-6" id="privacy-policy-section">
          <div className="border-b border-stone-200 pb-5">
            <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
              Legal Disclosures
            </span>
            <h1 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-stone-900 uppercase mt-1">
              PRIVACY POLICIES & COMPLIANCE
            </h1>
          </div>

          <div className="text-xs text-stone-600 space-y-4 uppercase tracking-widest leading-relaxed">
            <p className="font-mono text-stone-450">EFFECTIVE TIMELINE DETECTED: A/W COLLECTIVE 2026</p>
            <p>{cmsContent.privacyPolicy}</p>
            <p>
              We prioritize data preservation utilizing SHA-256 standard encryption mechanisms on all transactions. Your address coordinates are referenced purely to compile order tracking flight receipts, and routing transaction alerts.
            </p>
          </div>
        </section>
      )}

      {/* 5. TERMS OF SERVICE */}
      {viewType === 'terms' && (
        <section className="space-y-6" id="terms-section">
          <div className="border-b border-stone-200 pb-5">
            <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
              Transaction Rules
            </span>
            <h1 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-stone-900 uppercase mt-1">
              TERMS OF BESPOKE SERVICE
            </h1>
          </div>

          <div className="text-xs text-stone-600 space-y-4 uppercase tracking-widest leading-relaxed">
            <p className="font-mono text-stone-450">MUTUAL PURCHASE AGREEMENTS DETECTED</p>
            <p>{cmsContent.termsOfService}</p>
            <p>
              All listed items are limited edition and created strictly for individual purchase. Intellectual layout designs, photo assets, typography coordinates, and custom fabric combinations remain the private possession of DURUB.
            </p>
          </div>
        </section>
      )}

    </div>
  );
}
