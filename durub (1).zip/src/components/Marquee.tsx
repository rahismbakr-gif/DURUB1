import React from "react";

interface MarqueeProps {
  text: string;
  speed?: number; // seconds for full cycle
}

export function Marquee({ text, speed = 25 }: MarqueeProps) {
  return (
    <div className="w-full bg-stone-50/50 text-stone-500 py-2.5 overflow-hidden border-y border-stone-100" id="announcement-marquee">
      <div className="relative flex w-full overflow-x-hidden">
        <div 
          className="animate-marquee whitespace-nowrap flex gap-16 text-[10px] md:text-xs font-mono tracking-[0.2em] uppercase py-0.5"
          style={{ animationDuration: `${speed}s` }}
        >
          <span>{text}</span>
          <span>{text}</span>
          <span>{text}</span>
          <span>{text}</span>
        </div>
        <div 
          className="animate-marquee whitespace-nowrap flex gap-16 text-[10px] md:text-xs font-mono tracking-[0.2em] uppercase py-0.5 absolute top-2.5 left-full h-full"
          style={{ animationDuration: `${speed}s`, animationDelay: `${speed / 2}s` }}
        >
          <span>{text}</span>
          <span>{text}</span>
          <span>{text}</span>
          <span>{text}</span>
        </div>
      </div>
    </div>
  );
}
