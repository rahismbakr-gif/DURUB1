import React, { useState } from "react";
import { Search, ShoppingBag, User, Settings, Menu, X, HelpCircle, Phone, Info, Sun, Moon } from "lucide-react";
import { Product } from "../types";
import { Language, translations } from "../lib/translations";

interface NavbarProps {
  cartCount: number;
  onNavigate: (view: string, categoryFilter?: string) => void;
  onSearch: (query: string) => void;
  currentView: string;
  categories: string[];
  activeCategory: string | null;
  lang?: Language;
  theme?: "light" | "dark";
  onToggleLanguage?: () => void;
  onToggleTheme?: () => void;
}

export function Navbar({ 
  cartCount, 
  onNavigate, 
  onSearch, 
  currentView, 
  categories,
  activeCategory,
  lang = "en",
  theme = "light",
  onToggleLanguage,
  onToggleTheme
}: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const t = (key: string) => {
    return translations[lang]?.[key] || key;
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
    onNavigate("shop");
  };

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    onSearch(e.target.value);
  };

  return (
    <header className="sticky top-0 z-45 bg-white dark:bg-stone-950 border-b border-stone-100 dark:border-stone-900 transition-colors duration-200" id="main-header">
      {/* Top micro ribbon */}
      <div className="bg-stone-50/50 dark:bg-stone-900/40 py-2 px-4 border-b border-stone-100 dark:border-stone-900 hidden md:flex justify-center items-center text-[10px] tracking-widest font-mono text-stone-400 dark:text-stone-500 uppercase">
        <div className="flex items-center gap-1.5">
          <span>{t("top_ribbon")}</span>{" "}
          <a 
            href="https://durub.com" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-stone-900 dark:text-stone-250 hover:text-stone-600 underline font-semibold transition-colors duration-200"
          >
            DURUB.COM
          </a>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
        
        {/* Left Side: Mobile Hamburger & Search Input */}
        <div className="flex items-center gap-4 lg:w-1/4">
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} 
            className="lg:hidden text-zinc-900 dark:text-stone-100 focus:outline-hidden hover:text-stone-500"
            id="mobile-menu-trigger"
          >
            {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>

          {/* Search Bar - Desktop */}
          <form onSubmit={handleSearchSubmit} className="hidden lg:flex items-center border border-stone-200 dark:border-stone-800 focus-within:border-zinc-900 dark:focus-within:border-stone-500 bg-stone-50 dark:bg-stone-900 px-3 py-1.5 w-full max-w-[220px] transition-colors relative">
            <Search size={14} className="text-stone-400 mr-2" />
            <input
              type="text"
              placeholder={t("search_placeholder")}
              className="bg-transparent text-xs uppercase placeholder:text-stone-300 dark:placeholder:text-stone-700 focus:outline-hidden text-zinc-850 dark:text-stone-100 tracking-wider w-full"
              value={searchQuery}
              onChange={handleQueryChange}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setTimeout(() => setSearchFocused(false), 200)}
            />
          </form>
        </div>

        {/* Center: Brand Identifier Logo */}
        <div className="text-center flex-grow lg:w-2/4 flex justify-center">
          <button 
            onClick={() => { onNavigate("home"); setSearchQuery(""); }} 
            className="text-stone-950 dark:text-white hover:opacity-70 transition-opacity font-serif font-light tracking-[0.25em] text-3xl md:text-4xl uppercase cursor-pointer animate-fade-in"
            id="navbar-brand-logo"
          >
            {t("logo_text")}
          </button>
        </div>

        {/* Right Side: Interactive Actions */}
        <div className="flex items-center justify-end gap-3 md:gap-5 lg:w-1/4 text-zinc-900 dark:text-stone-100">
          {/* DURUB Studio (Our elegant Wix CMS Admin Panel) */}
          <button 
            onClick={() => onNavigate("admin")}
            className={`flex items-center gap-1 px-2.5 py-1.5 text-[10px] md:text-xs font-mono tracking-widest uppercase transition-all border outline-hidden cursor-pointer ${
              currentView === "admin" 
                ? "bg-stone-950 text-white border-stone-950" 
                : "bg-white dark:bg-stone-900 hover:bg-stone-50 dark:hover:bg-stone-800 text-stone-900 dark:text-stone-100 border-stone-200 dark:border-stone-800 font-bold shadow-xs"
            }`}
            id="navbar-studio-action"
            title={t("studio_portal")}
          >
            <Settings size={13} className="animate-spin-slow" />
            <span className="inline font-bold">{t("studio_portal")}</span>
          </button>

          {/* Track Order/Account Button */}
          <button 
            onClick={() => onNavigate("account")}
            className={`hover:text-stone-500 cursor-pointer ${currentView === "account" ? "text-stone-500 underline animate-pulse" : ""}`}
            title={t("customer_account")}
            id="navbar-account-action"
          >
            <User size={18} />
          </button>

          {/* Shopping Bag Trigger */}
          <button 
            onClick={() => onNavigate("cart")}
            className="relative p-1 hover:text-stone-500 flex items-center cursor-pointer"
            id="navbar-cart-action"
          >
            <ShoppingBag size={18} />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-stone-950 dark:bg-white text-white dark:text-stone-950 text-[8px] font-mono h-4 w-4 rounded-full flex items-center justify-center font-bold tracking-tighter">
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Categories Horizontal Banner - Desktop only */}
      <nav className="border-t border-stone-100 dark:border-stone-900 bg-white dark:bg-stone-950 hidden lg:block py-3.5 transition-colors duration-200">
        <div className="max-w-7xl mx-auto px-8 flex justify-center gap-10">
          <button 
            onClick={() => { onNavigate("shop", undefined); }}
            className={`text-[11px] font-mono tracking-widest text-zinc-900 dark:text-stone-150 transition-colors uppercase cursor-pointer hover:text-zinc-500 ${
              currentView === "shop" && activeCategory === null ? "border-b border-black dark:border-white font-semibold" : ""
            }`}
          >
            {lang === "en" ? "ALL CLOTHING" : "كل الملابس"}
          </button>
          
          {categories.map((cat) => (
            <button 
              key={cat}
              onClick={() => { onNavigate("shop", cat); }}
              className={`text-[11px] font-mono tracking-widest text-zinc-900 dark:text-stone-150 transition-colors uppercase cursor-pointer hover:text-zinc-500 ${
                activeCategory === cat ? "border-b border-black dark:border-white font-semibold" : ""
              }`}
            >
              {cat}
            </button>
          ))}
          
          <button 
            onClick={() => onNavigate("about")}
            className={`text-[11px] font-mono tracking-widest text-zinc-900 dark:text-stone-150 transition-colors uppercase cursor-pointer hover:text-zinc-500 ${
              currentView === "about" ? "border-b border-black dark:border-white font-semibold" : ""
            }`}
          >
            {lang === "en" ? "ESSENCE (ABOUT)" : "عن الأتيليه"}
          </button>

          <button 
            onClick={() => onNavigate("admin")}
            className={`text-[11px] font-mono tracking-widest text-stone-900 dark:text-stone-100 font-bold transition-colors uppercase cursor-pointer hover:text-stone-500 ${
              currentView === "admin" ? "border-b-2 border-stone-950 dark:border-stone-100 pb-0.5" : ""
            }`}
          >
            🛠️ DURUB STUDIO
          </button>
        </div>
      </nav>

      {/* Mobile Menu Slide Drawer */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-white/98 flex flex-col pt-24 px-6 animate-fade-in transition-all duration-300">
          {/* Quick Search */}
          <form onSubmit={handleSearchSubmit} className="flex items-center border border-stone-300 bg-stone-50 px-3 py-2 w-full mb-6">
            <Search size={15} className="text-stone-400 mr-2" />
            <input
              type="text"
              placeholder="SEARCH PRODUCTS..."
              className="bg-transparent text-xs uppercase placeholder:text-stone-300 focus:outline-hidden text-zinc-850 tracking-wider w-full"
              value={searchQuery}
              onChange={handleQueryChange}
            />
          </form>

          <span className="text-[10px] font-mono tracking-wider text-stone-400 uppercase mb-3 border-b pb-1">
            SHOP BY COLLECTION
          </span>
          <div className="flex flex-col gap-4 mb-8">
            <button 
              onClick={() => { onNavigate("shop", undefined); setIsMobileMenuOpen(false); }}
              className={`text-sm tracking-widest uppercase text-left py-1 cursor-pointer font-medium ${
                currentView === "shop" && activeCategory === null ? "text-stone-500 font-bold" : "text-stone-900"
              }`}
            >
              ALL CLOTHING
            </button>
            {categories.map((cat) => (
              <button 
                key={cat}
                onClick={() => { onNavigate("shop", cat); setIsMobileMenuOpen(false); }}
                className={`text-sm tracking-widest uppercase text-left py-1 cursor-pointer ${
                  activeCategory === cat ? "text-stone-500 font-bold" : "text-stone-900"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <span className="text-[10px] font-mono tracking-wider text-stone-400 uppercase mb-3 border-b pb-1">
            DURUB STUDIO & JOURNAL
          </span>
          <div className="flex flex-col gap-3 text-xs tracking-wider uppercase text-zinc-650">
            <button 
              onClick={() => { onNavigate("admin"); setIsMobileMenuOpen(false); }}
              className="text-left font-mono py-1 text-stone-900 dark:text-stone-100 cursor-pointer"
            >
              🛠️ DURUB STUDIO (CMS / ADMIN)
            </button>
            <button 
              onClick={() => { onNavigate("account"); setIsMobileMenuOpen(false); }}
              className="text-left py-1 cursor-pointer"
            >
              📦 ORDER TRACKING & ME
            </button>
            <button 
              onClick={() => { onNavigate("about"); setIsMobileMenuOpen(false); }}
              className="text-left py-1 cursor-pointer"
            >
              ABOUT THE ESSENCE
            </button>
            <button 
              onClick={() => { onNavigate("faq"); setIsMobileMenuOpen(false); }}
              className="text-left py-1 cursor-pointer"
            >
              FAQ / DISPATCH INFOS
            </button>
            <button 
              onClick={() => { onNavigate("contact"); setIsMobileMenuOpen(false); }}
              className="text-left py-1 cursor-pointer"
            >
              CONTACT CUSTOMER SERVICE
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
