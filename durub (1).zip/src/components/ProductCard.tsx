import React, { useState } from "react";
import { Product } from "../types";

interface ProductCardProps {
  product: Product;
  onClick: (product: Product) => void;
}

export function ProductCard({ product, onClick }: ProductCardProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const hasMultipleImages = product.images.length > 1;

  return (
    <div 
      className="group cursor-pointer flex flex-col h-full bg-white relative animate-fade-in"
      onClick={() => onClick(product)}
      id={`product-card-${product.id}`}
    >
      {/* Badges */}
      <div className="absolute top-3 left-3 z-10 flex flex-col gap-1.5 pointer-events-none">
        {product.isNew && (
          <span className="bg-zinc-950 text-white text-[8px] md:text-[9px] font-mono tracking-widest px-2.5 py-1 uppercase rounded-none">
            New
          </span>
        )}
        {product.isBestSeller && (
          <span className="bg-amber-800 text-white text-[8px] md:text-[9px] font-mono tracking-widest px-2.5 py-1 uppercase rounded-none">
            Best Seller
          </span>
        )}
        {product.originalPrice && product.originalPrice > product.price && (
          <span className="bg-stone-200 text-stone-900 text-[8px] md:text-[9px] font-mono tracking-widest px-2.5 py-1 uppercase rounded-none">
            Sale
          </span>
        )}
      </div>

      {/* Image container with double image hover switch */}
      <div 
        className="relative aspect-[3/4] bg-stone-100 overflow-hidden"
        onMouseEnter={() => hasMultipleImages && setCurrentImageIndex(1)}
        onMouseLeave={() => setCurrentImageIndex(0)}
      >
        <img
          src={product.images[currentImageIndex] || product.images[0]}
          alt={product.name}
          className="w-full h-full object-cover transition-transform duration-[1200ms] cubic-bezier(0.16, 1, 0.3, 1) group-hover:scale-105"
          loading="lazy"
          referrerPolicy="no-referrer"
        />
        
        {/* Rapid Preview Quick-Add strip on hover */}
        <div className="absolute bottom-0 left-0 w-full bg-white/90 backdrop-blur-xs py-3 text-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 border-t border-stone-200/55">
          <span className="text-[10px] font-mono tracking-widest uppercase text-stone-950">
            View Details
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="pt-4 pb-2 flex flex-col flex-grow items-center text-center">
        <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-stone-400 mb-1">
          {product.category}
        </span>
        <h3 className="text-xs md:text-[13px] font-serif font-light tracking-widest text-stone-950 group-hover:text-stone-500 uppercase transition-colors duration-200 line-clamp-2 px-2">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-2 mt-1.5">
          <span className="text-xs md:text-sm font-mono text-stone-900">
            EGP {product.price.toFixed(2)}
          </span>
          {product.originalPrice && (
            <span className="text-xs font-mono text-stone-400 line-through">
              EGP {product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>

        {/* Sizes display */}
        <div className="mt-3 flex flex-wrap justify-center gap-1">
          {product.sizes.map((s) => (
            <span 
              key={s} 
              className="text-[9px] font-mono border border-stone-200 bg-stone-50 px-1.5 py-0.5 text-stone-500"
            >
              {s}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
