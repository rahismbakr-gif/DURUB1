import React, { useState, useMemo } from "react";
import { Product } from "../types";
import { ChevronLeft, ShoppingBag, Check, ZoomIn, ZoomOut, AlertCircle, Info } from "lucide-react";

interface ProductDetailViewProps {
  product: Product;
  allProducts: Product[];
  onBack: () => void;
  onAddToBag: (product: Product, quantity: number, size: string, color: string) => void;
  onSelectProduct: (product: Product) => void;
}

export function ProductDetailView({
  product,
  allProducts,
  onBack,
  onAddToBag,
  onSelectProduct
}: ProductDetailViewProps) {
  const [selectedImage, setSelectedImage] = useState(product.images[0]);
  const [selectedSize, setSelectedSize] = useState("");
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || "Default");
  const [quantity, setQuantity] = useState(1);
  const [addedMessage, setAddedMessage] = useState(false);
  const [sizeWarning, setSizeWarning] = useState(false);

  // Loupe Zoom settings
  const [zoomScale, setZoomScale] = useState(1.0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const relatedProducts = useMemo(() => {
    return allProducts
      .filter((p) => p.category === product.category && p.id !== product.id)
      .slice(0, 4);
  }, [allProducts, product]);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const { left, top, width, height } = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setMousePos({ x, y });
  };

  const handleAddClick = () => {
    if (!selectedSize) {
      setSizeWarning(true);
      return;
    }
    setSizeWarning(false);
    
    // Add to standard cart ledger
    onAddToBag(product, quantity, selectedSize, selectedColor);
    
    setAddedMessage(true);
    setTimeout(() => {
      setAddedMessage(false);
    }, 4000);
  };

  const colorHexClass = (colName: string) => {
    const match = product.colors.find(c => c.name === colName);
    return match ? match.class : "bg-stone-200";
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in" id="product-detail-layout">
      
      {/* Breadcrumb / Back Navigation */}
      <button 
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-mono tracking-widest text-stone-500 hover:text-stone-950 uppercase mb-8 cursor-pointer group"
      >
        <ChevronLeft size={14} className="group-hover:-translate-x-1 transition-transform" />
        <span>Back to Campaigns</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
        
        {/* Left Side: Images Section (Grid + interactive Thumbnails) */}
        <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-12 gap-4">
          
          {/* Thumbnails list */}
          <div className="md:col-span-2 flex md:flex-col gap-3 order-2 md:order-1 h-fit">
            {product.images.map((img, i) => (
              <button
                key={i}
                onClick={() => { setSelectedImage(img); setIsZoomed(false); setZoomScale(1.0); }}
                className={`aspect-[3/4] border w-16 md:w-full bg-stone-100 overflow-hidden cursor-pointer transition-colors ${
                  selectedImage === img ? "border-zinc-950" : "border-stone-200"
                }`}
              >
                <img src={img} alt="Thumb" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </button>
            ))}
          </div>

          {/* Core high-quality view display area with interactive Magnifier hover */}
          <div className="md:col-span-10 order-1 md:order-2 relative bg-stone-100 aspect-[3/4] overflow-hidden border border-stone-200">
            <div 
              className="w-full h-full relative cursor-zoom-in"
              onMouseMove={handleMouseMove}
              onMouseEnter={() => setIsZoomed(true)}
              onMouseLeave={() => { setIsZoomed(false); setZoomScale(1.0); }}
            >
              <img
                src={selectedImage}
                alt={product.name}
                className="w-full h-full object-cover transition-transform duration-100"
                style={{
                  transform: isZoomed ? `scale(${zoomScale === 1.0 ? 1.6 : zoomScale})` : "scale(1.0)",
                  transformOrigin: `${mousePos.x}% ${mousePos.y}%`
                }}
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Scale multiplier controller widgets */}
            <div className="absolute bottom-4 right-4 z-10 flex gap-2 bg-white/93 backdrop-blur-xs p-1.5 border border-stone-200 shadow-xs">
              <button 
                onClick={() => { setZoomScale(prev => Math.min(prev + 0.2, 2.5)); setIsZoomed(true); }}
                className="p-1 hover:bg-stone-50 text-stone-700 cursor-pointer"
                title="Increase Zoom Scale"
              >
                <ZoomIn size={14} />
              </button>
              <span className="text-[10px] font-mono leading-relaxed px-1 text-stone-500 self-center">
                {isZoomed ? `ZOOMED` : `HOVER TO LOUPE`}
              </span>
              <button 
                onClick={() => { setZoomScale(prev => Math.max(prev - 0.2, 1.0)); }}
                className="p-1 hover:bg-stone-50 text-stone-700 cursor-pointer"
                title="Decrease Zoom"
              >
                <ZoomOut size={14} />
              </button>
            </div>
          </div>
        </div>

        {/* Right Side: Options & Actions */}
        <div className="lg:col-span-5 flex flex-col justify-between">
          <div className="space-y-6">
            
            {/* Headers details */}
            <div>
              <div className="flex gap-2">
                {product.isNew && (
                  <span className="bg-zinc-950 text-white text-[8px] font-mono px-2 py-0.5 tracking-widest uppercase">
                    New Campaign
                  </span>
                )}
                {product.isBestSeller && (
                  <span className="bg-amber-800 text-white text-[8px] font-mono px-2 py-0.5 tracking-widest uppercase">
                    Best Seller
                  </span>
                )}
              </div>
              
              <h1 className="font-serif text-2xl md:text-3xl font-light tracking-[0.18em] uppercase text-stone-950 mt-3 animate-fade-in">
                {product.name}
              </h1>

              <div className="flex items-center gap-3 mt-3">
                <span className="font-mono text-lg text-stone-900">
                  EGP {product.price.toFixed(2)}
                </span>
                {product.originalPrice && (
                  <span className="font-sans line-through text-stone-400 text-sm">
                    EGP {product.originalPrice.toFixed(2)}
                  </span>
                )}
              </div>
            </div>

            {/* Sizing choosing blocks */}
            <div className="border-t border-stone-200 pt-5">
              <div className="flex justify-between items-center text-[10px] font-mono text-stone-500 tracking-wider mb-2">
                <span>SELECT PREVALENT SIZE</span>
                <span className="underline uppercase hover:text-black cursor-pointer">View Size Chart</span>
              </div>
              
              <div className="flex flex-wrap gap-2.5">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => { setSelectedSize(s); setSizeWarning(false); }}
                    className={`h-11 min-w-[50px] px-3 font-mono text-xs transition-all border cursor-pointer ${
                      selectedSize === s
                        ? "bg-stone-950 text-white border-stone-950 font-bold"
                        : "bg-white text-stone-900 border-stone-200 hover:border-black"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              {sizeWarning && (
                <p className="text-[10px] font-mono text-red-460 flex items-center gap-1 mt-2.5 uppercase tracking-wide">
                  <AlertCircle size={12} /> Please select a sizing tag to continue.
                </p>
              )}
            </div>

            {/* Colors selection */}
            <div className="border-t border-stone-200 pt-5">
              <p className="text-[10px] font-mono text-stone-500 tracking-wider mb-2.5 uppercase">
                Campaign Palettes: <span className="text-stone-900 font-bold">{selectedColor}</span>
              </p>
              
              <div className="flex gap-3">
                {product.colors.map((col) => (
                  <button
                    key={col.name}
                    onClick={() => setSelectedColor(col.name)}
                    className={`h-8 w-8 rounded-full border flex items-center justify-center transition-transform hover:scale-115 cursor-pointer ${
                      selectedColor === col.name ? "border-zinc-950 ring-2 ring-stone-900/10" : "border-stone-200"
                    }`}
                    title={col.name}
                  >
                    <span className={`h-5 w-5 rounded-full ${col.class}`}></span>
                  </button>
                ))}
              </div>
            </div>

            {/* Inventory prompt alert */}
            <div className="bg-stone-50 border border-stone-200/50 p-3 flex gap-2">
              <Info size={14} className="text-stone-600 mt-0.5" />
              <div className="text-[10px] text-stone-500 uppercase tracking-wide">
                <span className="font-bold text-stone-950 font-mono">{product.inventory} UNITS AVAILABLE </span>
                at the distribution docks. Our tailors dispatch within 24 hours of checkout.
              </div>
            </div>

            {/* Description details */}
            <div className="border-t border-stone-200 pt-5">
              <p className="text-[10px] font-mono text-stone-500 tracking-wider uppercase mb-2">
                Atelier Chronicles
              </p>
              <p className="text-xs text-stone-500 leading-relaxed uppercase tracking-wider">
                {product.description}
              </p>
            </div>

            {/* Submit checkout buttons */}
            <div className="pt-4 space-y-3">
              <button
                onClick={handleAddClick}
                disabled={product.inventory <= 0}
                className={`w-full py-4 uppercase font-mono text-xs tracking-widest font-bold transition-colors inline-flex justify-center items-center gap-2.5 cursor-pointer ${
                  product.inventory <= 0
                    ? "bg-stone-200 text-stone-400 border border-stone-300 cursor-not-allowed"
                    : "bg-zinc-950 hover:bg-zinc-800 text-white"
                }`}
              >
                <ShoppingBag size={14} />
                <span>{product.inventory <= 0 ? "DEPLATED" : "ADD TO BASKET"}</span>
              </button>

              {addedMessage && (
                <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-3 text-[10px] font-mono tracking-widest uppercase text-center animate-fade-in space-y-1">
                  <div>✓ SILHOUETTE ADDED TO THE CORRESPONDING BAG.</div>
                  <div className="text-[9px] text-emerald-700 font-bold">✉ DESIGN DETAILS DISPATCHED TO ATELIER (rah.ism.bakr@gmail.com).</div>
                </div>
              )}
            </div>

          </div>
        </div>
      </div>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <div className="mt-24 border-t border-stone-200 pt-16">
          <div className="flex justify-between items-end mb-10">
            <div>
              <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
                Matching Esthetics
              </span>
              <h3 className="font-display text-lg uppercase tracking-widest text-stone-950">
                RELATED HARMONIES
              </h3>
            </div>
            <button 
              onClick={onBack}
              className="text-xs font-mono tracking-widest text-stone-900 underline hover:text-stone-500 uppercase cursor-pointer"
            >
              Browse All
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {relatedProducts.map((p) => (
              <div 
                key={p.id} 
                onClick={() => { onSelectProduct(p); window.scrollTo(0,0); setSelectedImage(p.images[0]); setSelectedSize(""); }}
                className="group cursor-pointer flex flex-col bg-white overflow-hidden text-left"
              >
                <div className="aspect-[3/4] bg-stone-100 relative overflow-hidden">
                  <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-103" referrerPolicy="no-referrer" />
                </div>
                <h4 className="text-[11px] uppercase tracking-wider text-stone-950 mt-3 group-hover:text-stone-500 line-clamp-1">
                  {p.name}
                </h4>
                <p className="text-[10px] font-mono text-stone-500 mt-1">EGP {p.price.toFixed(2)}</p>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}
