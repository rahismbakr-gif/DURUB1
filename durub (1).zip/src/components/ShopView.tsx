import React, { useState, useMemo } from "react";
import { Product } from "../types";
import { ProductCard } from "./ProductCard";
import { SlidersHorizontal, ArrowUpDown, ChevronDown } from "lucide-react";

interface ShopViewProps {
  products: Product[];
  activeCategory: string | null;
  onSelectCategory: (cat: string | null) => void;
  onSelectProduct: (p: Product) => void;
  searchQuery: string;
}

export function ShopView({
  products,
  activeCategory,
  onSelectCategory,
  onSelectProduct,
  searchQuery
}: ShopViewProps) {
  const [sortBy, setSortBy] = useState<'relevance' | 'priceLowHigh' | 'priceHighLow'>('relevance');

  // Filter categories
  const categories = useMemo(() => {
    const list = new Set(products.map(p => p.category));
    return Array.from(list);
  }, [products]);

  // Apply filters and search queries
  const processedProducts = useMemo(() => {
    let list = [...products];

    // Category filter
    if (activeCategory) {
      list = list.filter(p => p.category.toLowerCase() === activeCategory.toLowerCase());
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(p => 
        p.name.toLowerCase().includes(q) || 
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }

    // Sort order
    if (sortBy === 'priceLowHigh') {
      list.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'priceHighLow') {
      list.sort((a, b) => b.price - a.price);
    }

    return list;
  }, [products, activeCategory, searchQuery, sortBy]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 animate-fade-in" id="shop-view-wrapper">
      
      {/* Category header display */}
      <div className="border-b border-stone-200 pb-6 mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <span className="text-[10px] font-mono tracking-widest text-stone-400 uppercase">
            Curated Campaigned Catalog
          </span>
          <h2 className="font-display text-2xl md:text-3xl font-medium tracking-widest text-stone-900 mt-1 uppercase">
            {activeCategory || "ALL CLOTHING"}
          </h2>
          <p className="text-xs text-stone-500 font-mono mt-1">
            Displaying {processedProducts.length} of {products.length} tactile masterworks.
          </p>
        </div>

        {/* Filters/Sort bar */}
        <div className="flex flex-wrap items-center gap-4 text-xs">
          <div className="inline-flex items-center gap-2 text-stone-500 border border-stone-200 bg-stone-50 px-3 py-2 uppercase font-mono text-[10px] tracking-wider">
            <SlidersHorizontal size={12} />
            <span>Filter Categories:</span>
            <select
              value={activeCategory || ""}
              onChange={(e) => onSelectCategory(e.target.value ? e.target.value : null)}
              className="bg-transparent focus:outline-hidden text-stone-900 font-bold"
            >
              <option value="">SHOW ALL</option>
              {categories.map(c => (
                <option key={c} value={c}>{c.toUpperCase()}</option>
              ))}
            </select>
          </div>

          <div className="inline-flex items-center gap-2 text-stone-500 border border-stone-200 bg-stone-50 px-3 py-2 uppercase font-mono text-[10px] tracking-wider">
            <ArrowUpDown size={12} />
            <span>Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent focus:outline-hidden text-stone-900 font-bold"
            >
              <option value="relevance">RELEVANCE</option>
              <option value="priceLowHigh">PRICE: LOW TO HIGH</option>
              <option value="priceHighLow">PRICE: HIGH TO LOW</option>
            </select>
          </div>
        </div>
      </div>

      {searchQuery && (
        <div className="mb-6 bg-stone-50 text-stone-800 text-xs py-3 px-4 uppercase font-mono tracking-wider border border-stone-200">
          🔍 CURRENT FILTER: QUERYING "{searchQuery}" —{" "}
          <button 
            onClick={() => { window.location.reload(); }} 
            className="underline text-black font-bold ml-1"
          >
            Clear Search
          </button>
        </div>
      )}

      {/* Product Grid */}
      {processedProducts.length === 0 ? (
        <div className="text-center py-24 bg-stone-50 border border-stone-200/50">
          <p className="font-mono text-xs uppercase tracking-widest text-stone-400">
            No matching exquisite silhouettes found in this drawer.
          </p>
          <button 
            onClick={() => { onSelectCategory(null); }} 
            className="mt-4 bg-zinc-950 text-white text-[10px] font-mono tracking-widest uppercase px-6 py-3 hover:bg-zinc-800 cursor-pointer"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-12">
          {processedProducts.map((p) => (
            <ProductCard 
              key={p.id}
              product={p}
              onClick={onSelectProduct}
            />
          ))}
        </div>
      )}

      {/* Stylized bento info card footer */}
      <div className="mt-20 border-t border-stone-200 pt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="border-l border-stone-300 pl-4">
          <h4 className="font-mono text-[10px] tracking-widest uppercase text-stone-900 font-bold">
            TACTILITY ASSURANCE
          </h4>
          <p className="text-xs text-stone-500 uppercase tracking-wide leading-relaxed mt-1">
            Every garment begins with uncompromised fiber exploration. Sand washes, double mercerized knits, and organic flax blends prioritize sensory wear longevity.
          </p>
        </div>
        <div className="border-l border-stone-300 pl-4">
          <h4 className="font-mono text-[10px] tracking-widest uppercase text-stone-900 font-bold">
            GLOBAL ATELIER CARGO
          </h4>
          <p className="text-xs text-stone-500 uppercase tracking-wide leading-relaxed mt-1">
            Our distribution hubs package each garment in biodegradable paper shells. Courier tracking numbers are auto-routed within 1 hour.
          </p>
        </div>
        <div className="border-l border-stone-300 pl-4">
          <h4 className="font-mono text-[10px] tracking-widest uppercase text-stone-900 font-bold">
            LIMIT QUANTIZATION
          </h4>
          <p className="text-xs text-stone-500 uppercase tracking-wide leading-relaxed mt-1">
            To prevent catastrophic material wastage, we generate less than 150 instances of any design. Retired SKUs are purged from master records.
          </p>
        </div>
      </div>

    </div>
  );
}
