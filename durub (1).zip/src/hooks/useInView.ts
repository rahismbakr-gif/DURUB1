import { useEffect, useRef, useState } from "react";

export function useInView(options?: IntersectionObserverInit & { triggerOnce?: boolean }) {
  const ref = useRef<HTMLElement | null>(null);
  const [isInView, setIsInView] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        setIsInView(true);
        if (options?.triggerOnce !== false) {
          observer.unobserve(el);
        }
      } else {
        if (options?.triggerOnce === false) {
          setIsInView(false);
        }
      }
    }, options);

    observer.observe(el);

    return () => {
      if (el) observer.unobserve(el);
    };
  }, [options]);

  return [ref, isInView] as const;
}
