export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number; // For sale tags
  description: string;
  category: string;
  images: string[];
  sizes: string[];
  colors: { name: string; class: string }[];
  inventory: number;
  isNew?: boolean;
  isBestSeller?: boolean;
  featured?: boolean;
}

export interface OrderItem {
  product: Product;
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface Order {
  id: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  shippingAddress: string;
  city: string;
  zipCode: string;
  items: OrderItem[];
  subtotal: number;
  discount: number;
  total: number;
  date: string;
  status: 'Pending' | 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  trackingNumber?: string;
  couponApplied?: string;
}

export interface Customer {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  orders: string[]; // Order IDs
  createdAt: string;
}

export interface Coupon {
  id: string;
  code: string;
  type: 'percentage' | 'fixed';
  value: number;
  minSpend?: number;
  active: boolean;
}

export interface CMSContent {
  hero: {
    title: string;
    subtitle: string;
    ctaText: string;
    image: string;
  };
  promoMessage: string;
  collectionBanners: {
    minimalistLineTitle: string;
    minimalistLineImage: string;
    tailoredSuitingTitle: string;
    tailoredSuitingImage: string;
    essentialsTitle: string;
    essentialsImage: string;
  };
  aboutStory: string;
  aboutImage: string;
  faqs: { question: string; answer: string; category: string }[];
  privacyPolicy: string;
  termsOfService: string;
}

// Initial seed data
export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "prod-1",
    name: "OVERSIZED SEERSUCKER SHIRT",
    price: 69.90,
    originalPrice: 89.90,
    description: "Relaxed-fit shirt made of seersucker cotton blend fabric. Spread collar and elbow-length sleeves. Button-up front.",
    category: "Shirts",
    images: [
      "https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["S", "M", "L", "XL"],
    colors: [
      { name: "Off-White", class: "bg-stone-100 border border-stone-300" },
      { name: "Sage", class: "bg-emerald-800" },
      { name: "Slate Gray", class: "bg-zinc-600" }
    ],
    inventory: 15,
    isNew: true,
    featured: true
  },
  {
    id: "prod-2",
    name: "PREMIUM LINEN TROUSERS",
    price: 89.90,
    description: "Straight-leg trousers made of luxury medium-weight linen. Elastic waistband with adjustable interior drawstring. Front pockets and back patch pockets.",
    category: "Trousers",
    images: [
      "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1479064555552-3ef4979f8908?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "Sand", class: "bg-amber-100 border border-stone-300" },
      { name: "Black", class: "bg-stone-900" }
    ],
    inventory: 24,
    isBestSeller: true,
    featured: true
  },
  {
    id: "prod-3",
    name: "HEAVYWEIGHT COTTON T-SHIRT",
    price: 39.90,
    description: "T-shirt made of high-quality compact spun long-staple cotton fibers. Boxy oversized fit. Round rib knit neck.",
    category: "T-Shirts",
    images: [
      "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["S", "M", "L", "XL", "XXL"],
    colors: [
      { name: "Pure Black", class: "bg-stone-950" },
      { name: "Off-White", class: "bg-stone-100 border border-zinc-300" },
      { name: "Oatmeal", class: "bg-stone-200 border border-zinc-300" }
    ],
    inventory: 40,
    isNew: true,
    isBestSeller: true
  },
  {
    id: "prod-4",
    name: "RELAXED DRY-TOUCH JEANS",
    price: 79.90,
    originalPrice: 99.90,
    description: "Five-pocket rigid denim trousers. Mid-rise wide-leg silhouette. Front zip fly and metal button closure. Luxury wash finish.",
    category: "Jeans",
    images: [
      "https://images.unsplash.com/photo-1542272604-787c3835535d?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["30", "31", "32", "34"],
    colors: [
      { name: "Indigo Gray", class: "bg-stone-400" },
      { name: "Washed Black", class: "bg-zinc-800" }
    ],
    inventory: 18,
    isBestSeller: true
  },
  {
    id: "prod-5",
    name: "MINIMALIST SUEDE JACKET",
    price: 199.00,
    description: "Gloveweight premium goat suede jacket. Stand collar with press stud detailing. Front luxury silver zip closure. Elasticated hem.",
    category: "Jackets",
    images: [
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["M", "L", "XL"],
    colors: [
      { name: "Espresso", class: "bg-amber-950" },
      { name: "Charcoal", class: "bg-zinc-700" }
    ],
    inventory: 8,
    isNew: true,
    featured: true
  },
  {
    id: "prod-6",
    name: "MINIMALIST LEATHER SNEAKERS",
    price: 129.00,
    description: "Premium smooth leather low-top sneakers. Fully lined in calves leather. margom Italian rubber outsole. Clean tonal stitching.",
    category: "Shoes",
    images: [
      "https://images.unsplash.com/photo-1549298916-b41d501d3772?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["41", "42", "43", "44", "45"],
    colors: [
      { name: "Chalk White", class: "bg-zinc-50 border border-zinc-200" },
      { name: "Jet Black", class: "bg-zinc-900" }
    ],
    inventory: 12,
    isBestSeller: true
  },
  {
    id: "prod-7",
    name: "ARCHITECTURAL ACETATE SUNGLASSES",
    price: 59.90,
    description: "Thick hand-sculpted bio-acetate frame. 100% UVA/UVB protective dark tinted lenses. Internal DURUB golden branding detail.",
    category: "Accessories",
    images: [
      "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&q=80&w=1000",
      "https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&q=80&w=1000"
    ],
    sizes: ["One Size"],
    colors: [
      { name: "Noir", class: "bg-zinc-950" },
      { name: "Tortoise", class: "bg-yellow-950" }
    ],
    inventory: 30,
    isNew: true
  }
];

export const INITIAL_CMS: CMSContent = {
  hero: {
    title: "AUTUMN / WINTER 26",
    subtitle: "A silent collection centered around tactile fabrics, structured draping, and modern architectural tailoring designed for permanence.",
    ctaText: "EXPLORE THE CAMPAIGN",
    image: "https://images.unsplash.com/photo-1516257984-b1b4d707412e?auto=format&fit=crop&q=80&w=1800"
  },
  promoMessage: "COMPLIMENTARY SHIPPING GLOBALLY FOR ORDERS OVER EGP 1500 — DISCOVER TIMELESS WARDROBE ESSENTIALS",
  collectionBanners: {
    minimalistLineTitle: "THE MINIMALIST COLLECTION",
    minimalistLineImage: "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&q=80&w=1000",
    tailoredSuitingTitle: "ARCHITECTURAL TAILORING",
    tailoredSuitingImage: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&q=80&w=1000",
    essentialsTitle: "PERMANENT ESSENTIALS",
    essentialsImage: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&q=80&w=1000"
  },
  aboutStory: "Founded under the ethos of architectural construction and silent luxury, DURUB manufactures high-art garments and modern artifacts in limited, ethical runs. Each silhouette represents a study in spatial volume, precise drape, and premium fiber source. We reject seasonal trends in favor of enduring form, designed to exist gracefully across generations.",
  aboutImage: "https://images.unsplash.com/photo-1479064555552-3ef4979f8908?auto=format&fit=crop&q=80&w=1200",
  faqs: [
    {
      category: "Shipping",
      question: "What are your shipping methods and delivery timelines?",
      answer: "We offer complimentary standard shipping globally on orders exceeding EGP 1500. Delivery times range from 2 to 4 business days for domestic shipments and 5 to 7 business days for global express shipping. Tracking information is sent automatically via email upon dispatch."
    },
    {
      category: "Returns",
      question: "What is your return and exchange policy?",
      answer: "We welcome returns of unworn, unaltered products with all original tags attached within 30 days of shipment receipt. To start a return, log into your DURUB account or contact support."
    },
    {
      category: "Sizing",
      question: "How do DURUB collection garments fit?",
      answer: "Most shirts and knits are cut for an architectural seersucker/oversized fit. We suggest selecting your regular size for the intended drape, or sizing down if you prefer a slim silhouette. Detailed measurements are present on each product card."
    },
    {
      category: "Sustainability",
      question: "Where are the products manufactured?",
      answer: "Our materials are sourced from heritage Italian and Japanese mills. Ethical assembly takes place in specialized small workshops across Portugal and Spain, ensuring fair wages and meticulous master tailoring execution."
    }
  ],
  privacyPolicy: "DURUB is committed to protecting your personal information. We gather, utilize, and process your coordinates exclusively to fulfill transaction requirements, deliver tailored updates, and improve your secure experience across our digital ecosystem. None of your private data is shared with uncertified entities.",
  termsOfService: "Purchase of goods and accessories from DURUB is strictly subject to core customer guidelines. All payments are processed securely via encrypted rails. We maintain full ownership rights over intellectual properties, imagery, and text assets."
};

export const INITIAL_COUPONS: Coupon[] = [
  { id: "c-1", code: "DURUB10", type: "percentage", value: 10, minSpend: 50, active: true },
  { id: "c-2", code: "WELCOME20", type: "fixed", value: 20, minSpend: 100, active: true },
  { id: "c-3", code: "SILENTVIP", type: "percentage", value: 15, active: true }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  {
    id: "cust-1",
    name: "Johnathan Stone",
    email: "john@stone.com",
    phone: "+1 555-893-0192",
    address: "742 Evergreen Terrace",
    orders: ["order-1011"],
    createdAt: "2026-01-15T11:20:00Z"
  }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: "order-1011",
    customerName: "Johnathan Stone",
    customerEmail: "john@stone.com",
    customerPhone: "+1 555-893-0192",
    shippingAddress: "742 Evergreen Terrace",
    city: "Springfield",
    zipCode: "97477",
    items: [
      {
        product: INITIAL_PRODUCTS[0],
        quantity: 1,
        selectedSize: "M",
        selectedColor: "Off-White"
      },
      {
        product: INITIAL_PRODUCTS[1],
        quantity: 1,
        selectedSize: "L",
        selectedColor: "Sand"
      }
    ],
    subtotal: 159.80,
    discount: 15.98,
    total: 143.82,
    date: "2026-06-22T14:30:00Z",
    status: "Delivered",
    trackingNumber: "DRB893019842US",
    couponApplied: "DURUB10"
  }
];
